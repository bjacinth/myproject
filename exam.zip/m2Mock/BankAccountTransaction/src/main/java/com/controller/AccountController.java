package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.entities.Account;
import com.repository.AccountRepository;
import com.service.IAccountService;

//Provide necessary Annotation
@RestController
public class AccountController {

//    private final AccountRepository accountRepository;
	
	//Provide necessary Annotation
	@Autowired
	IAccountService accountService;
//
//    AccountController(AccountRepository accountRepository) {
//        this.accountRepository = accountRepository;
//    }
	
	//Provide necessary Annotation and fill code
	@PostMapping("/openAccount")
	public ResponseEntity<Account> openAccount(@RequestBody Account account) {
	
		return new ResponseEntity<>(accountService.openAccount(account),HttpStatus.OK);
	}
	
	@GetMapping("/viewAccountByAccountNumber/{accountNumber}")
	public ResponseEntity<Account> viewAccountByAccountNumber( @PathVariable String accountNumber) {
		return new ResponseEntity<>( accountService.viewAccountByAccountNumber(accountNumber),HttpStatus.OK);
	}
	

	
}

	
