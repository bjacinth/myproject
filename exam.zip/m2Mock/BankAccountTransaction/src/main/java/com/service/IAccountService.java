package com.service;

import com.entities.Account;

public interface IAccountService {
	
	public Account openAccount(Account account);
	public Account viewAccountByAccountNumber(String accountNumber);


}
