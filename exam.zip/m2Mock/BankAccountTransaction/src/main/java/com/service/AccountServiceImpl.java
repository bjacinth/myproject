package com.service;


import com.entities.Account;
import com.repository.AccountRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class AccountServiceImpl implements IAccountService {
	
	//Provide code to Inject AccountRepository
	@Autowired
	public AccountRepository accountRepository;
	
		@Override
		public Account openAccount(Account account) {
			
			//fill code
			
			return accountRepository.save(account);
		}
		
		@Override
		public Account viewAccountByAccountNumber(String accountNumber) {
			
			//fill code
			
			return accountRepository.findById(accountNumber).get();	
		}
}