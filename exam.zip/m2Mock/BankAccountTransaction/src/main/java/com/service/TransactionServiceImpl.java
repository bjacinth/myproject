package com.service;

import java.time.LocalDate;
import java.util.List;

import com.entities.Account;
import com.entities.BankTransaction;
import com.repository.AccountRepository;
import com.repository.TransactionRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class TransactionServiceImpl implements ITransactionService {

	// Provide code to Inject TransactionRepository and AccountRepository
	// Provide code to Inject AccountRepository, if needed
	@Autowired
	public TransactionRepository repository;
	@Autowired
	public AccountRepository accountRepository;

	@Override
	public BankTransaction insertTransaction(BankTransaction transactionObj, String accountNumber) {

		// fill code
		Account bt = accountRepository.findById(accountNumber).get();
		if(transactionObj.getTransactionType()== "Deposit") {
			Double ammount = bt.getBalanceAmount()+transactionObj.getAmount();
			BankTransaction obj = new BankTransaction(transactionObj.getTransactionId(),LocalDate.now().toString(),"Deposit",transactionObj.getAmount());
			bt.setBalanceAmount(ammount);
			return obj;
		}
		else
		{
			Double ammount2 = bt.getBalanceAmount()-transactionObj.getAmount();
			BankTransaction obj = new BankTransaction(transactionObj.getTransactionId(),LocalDate.now().toString(),"Withdraw",transactionObj.getAmount());
			bt.setBalanceAmount(ammount2);
			return obj;
		}
		
	}

	public List<BankTransaction> viewTransactionByTransactionType(String transactionType) {
		// fill code

		return repository.findByTransactionByTransactionType(transactionType);
	}

	

}
