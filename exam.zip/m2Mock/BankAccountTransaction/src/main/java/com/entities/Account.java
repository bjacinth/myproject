package com.entities;

import java.util.List;

import jakarta.annotation.Nonnull;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

//Provide necessary Annotation
@Entity
@Getter
@Setter
@AllArgsConstructor
public class Account {
	
	//Provide necessary Annotation
	@Id
	@Column(length = 25)
	@Nonnull
	private String accountNumber;
	@Column(length = 25)
	private String holderName;
	@Column(length = 25)
	private String phoneNumber;
	@Column(length = 25)
	private String panNumber;
	@Column(length = 25)
	private String accountType; //Savings or Current
	@Nonnull
	private double balanceAmount;
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "transactionId")
	List<BankTransaction> transactions;
	
	public Account()
	    {
	        super();
	    }

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getHolderName() {
		return holderName;
	}

	public void setHolderName(String holderName) {
		this.holderName = holderName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public double getBalanceAmount() {
		return balanceAmount;
	}

	public void setBalanceAmount(double balanceAmount) {
		this.balanceAmount = balanceAmount;
	}

	public List<BankTransaction> getTransactions() {
		return transactions;
	}

	public void setTransactions(List<BankTransaction> transactions) {
		this.transactions = transactions;
	}

	public Account(String accountNumber, String holderName, String phoneNumber, String panNumber, String accountType,
			double balanceAmount, List<BankTransaction> transactions) {
		super();
		this.accountNumber = accountNumber;
		this.holderName = holderName;
		this.phoneNumber = phoneNumber;
		this.panNumber = panNumber;
		this.accountType = accountType;
		this.balanceAmount = balanceAmount;
		this.transactions = transactions;
	}

	@Override
	public String toString() {
		return "Account [accountNumber=" + accountNumber + ", holderName=" + holderName + ", phoneNumber=" + phoneNumber
				+ ", panNumber=" + panNumber + ", accountType=" + accountType + ", balanceAmount=" + balanceAmount
				+ ", transactions=" + transactions + "]";
	}
	
	
}
