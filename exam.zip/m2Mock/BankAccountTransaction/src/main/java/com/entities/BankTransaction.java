package com.entities;

import jakarta.annotation.Nonnull;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

//Provide necessary Annotation
@Entity
@Setter
@Getter
@AllArgsConstructor
public class BankTransaction {

	//Provide necessary Annotation
	@Id
	@Column(length = 25)
	@Nonnull
	private String transactionId;
	@Column(length = 25)
	private String transactionDate;
	@Column(length = 25)
	private String transactionType;//Deposit or Withdraw
	@Nonnull
	private double amount;
	@ManyToOne
	@JoinColumn(name = "account_number")
	private Account accountObj;
	
	 public BankTransaction() {
        super();
    }

	public BankTransaction(BankTransaction transactionObj) {
		// TODO Auto-generated constructor stub
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public String getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public Account getAccountObj() {
		return accountObj;
	}

	public void setAccountObj(Account accountObj) {
		this.accountObj = accountObj;
	}

	public BankTransaction(String transactionId, String transactionDate, String transactionType, double amount,
			Account accountObj) {
		super();
		this.transactionId = transactionId;
		this.transactionDate = transactionDate;
		this.transactionType = transactionType;
		this.amount = amount;
		this.accountObj = accountObj;
	}

	public BankTransaction(String transactionId2, String string, String string2, double amount2) {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "BankTransaction [transactionId=" + transactionId + ", transactionDate=" + transactionDate
				+ ", transactionType=" + transactionType + ", amount=" + amount + ", accountObj=" + accountObj + "]";
	}

	
	
	
}
