package com.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bean.School;
import com.bean.Student;
import com.repository.SchoolRepository;
import com.repository.StudentRepository;

@Service
public class SchoolDAO {
	@Autowired
	public StudentRepository studentRepository;
	@Autowired
	public SchoolRepository schoolRepository;
	
	public School addSchool(School school){
	    
	    return schoolRepository.save(school);
		
	}
	
	
	public List<Student> registerStudentToSchool(String schoolId, List<Student> students ) {
		
		School school = schoolRepository.findById(schoolId).get();
		
		for (Student student : students) {
			student.setSchool(school);
		}
		
		
		return studentRepository.saveAll(students);
	}

	
	public List<School> schoolWithMaximumStudents(String city){
		//List<School> schools = schoolRepository.findAll().stream().filter(s -> s.getCity().equals(city)).toList();
		//int max = schools.stream().max((s1,s2) -> Integer.compare(s1.getStudentList().size(), s2.getStudentList().size())).get().getStudentList().size();
//		return  schools.stream().filter(s->s.getCity().equals(city)).filter(s->s.getStudentList().size() == max).toList();
		return schoolRepository.schoolWithMaximumStudents(city);
	}
}
 