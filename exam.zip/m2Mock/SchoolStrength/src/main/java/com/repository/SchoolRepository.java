package com.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bean.School;

@Repository 
public interface SchoolRepository extends JpaRepository<School, String> {
	
	@Query( "select s from School s where s.city =:city and size(s.studentList) = (select max(size(s2.studentList)) from School s2 where s2.city =:city)")
	List<School> schoolWithMaximumStudents(@Param("city") String city);

}
