package com.bean;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Student {
	@Id
	private String studentRollNumber ; 
	private String studentName ; 
	private int studentAge ; 
	private String studentGender ; 
	private String studentGrade ; 
	private String studentSection ;
	@ManyToOne
	@JoinColumn(name = "schoolid" , referencedColumnName = "schoolId")
	@JsonBackReference
	private School school;
	
	public Student(String studentRollNumber, String studentName, int studentAge, String studentGender,
			String studentGrade, String studentSection, School school) {
		super();
		this.studentRollNumber = studentRollNumber;
		this.studentName = studentName;
		this.studentAge = studentAge;
		this.studentGender = studentGender;
		this.studentGrade = studentGrade;
		this.studentSection = studentSection;
		this.school = school;
	}
	
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}

	public School getSchool() {
		return school;
	}
	public void setSchool(School school) {
		this.school = school;
	}
	public String getStudentRollNumber() {
		return studentRollNumber;
	}
	public void setStudentRollNumber(String studentRollNumber) {
		this.studentRollNumber = studentRollNumber;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public int getStudentAge() {
		return studentAge;
	}
	public void setStudentAge(int studentAge) {
		this.studentAge = studentAge;
	}
	public String getStudentGender() {
		return studentGender;
	}
	public void setStudentGender(String studentGender) {
		this.studentGender = studentGender;
	}
	public String getStudentGrade() {
		return studentGrade;
	}
	public void setStudentGrade(String studentGrade) {
		this.studentGrade = studentGrade;
	}
	public String getStudentSection() {
		return studentSection;
	}
	public void setStudentSection(String studentSection) {
		this.studentSection = studentSection;
	} 
	
	
}
