package com.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.entities.Influencer;
import com.exception.InvalidInfluencerException;
import com.service.IInfluencerService;

import jakarta.validation.Valid;

//Provide necessary Annotation
@RestController

public class InfluencerController {

	// Provide necessary Annotation
	@Autowired
	private IInfluencerService influencerService;

	// Provide necessary Annotation for the below methods and fill the code
	@PostMapping("/addInfluencer")
	public ResponseEntity<Influencer> addInfluencer(@Valid @RequestBody Influencer influencer) {
		return new ResponseEntity<Influencer>(influencerService.addInfluencer(influencer),HttpStatus.OK);
	}
	@PutMapping("/appendFollowersCount/{influencerId}/{incrementCount}")
	public ResponseEntity<Influencer> appendFollowersCount(@Valid @PathVariable String influencerId, @PathVariable int incrementCount)throws InvalidInfluencerException {
		return new ResponseEntity<Influencer>(influencerService.appendFollowersCount(influencerId, incrementCount),HttpStatus.OK);
	}
	@GetMapping("/viewInfluencerById/{influencerId}")
	public ResponseEntity<Influencer> viewInfluencerById(@Valid @PathVariable String influencerId) throws InvalidInfluencerException {
		return new ResponseEntity<Influencer>(influencerService.viewInfluencerById(influencerId),HttpStatus.OK);
	}
	@GetMapping("/viewInfluencersByFollowersCount/{lowerLimit}/{higherLimit}")
	public ResponseEntity<List<Influencer>> viewInfluencersByFollowersCount(@PathVariable int lowerLimit,@PathVariable int higherLimit) {
		return new ResponseEntity<List<Influencer>>(influencerService.viewInfluencersByFollowersCount(lowerLimit, higherLimit),HttpStatus.OK);
	}
	@GetMapping("/getVideoCountInfluencerwise")
	public ResponseEntity<Map<String, Integer>> getVideoCountInfluencerwise() {
		return new ResponseEntity<Map<String,Integer>>(influencerService.getVideoCountInfluencerwise(),HttpStatus.OK);
	}
}
