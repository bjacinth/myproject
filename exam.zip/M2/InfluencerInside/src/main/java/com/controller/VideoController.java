package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.entities.Video;
import com.exception.InvalidInfluencerException;
import com.exception.InvalidVideoException;
import com.service.IVideoService;

import jakarta.validation.Valid;

//Provide necessary Annotation
@RestController
public class VideoController {

	// Provide necessary Annotation
	@Autowired
	private IVideoService videoService;

	// Provide necessary Annotation for the below methods and fill the code
	@PostMapping("/addVideo/{influencerId}")
	public ResponseEntity<Video> addVideo(@RequestBody Video video,@Valid @PathVariable String influencerId) throws InvalidInfluencerException {
		return new ResponseEntity<Video>(videoService.addVideo(video, influencerId),HttpStatus.OK);
	}
	@PutMapping("/updateTitle/{videoId}/{title}")
	public ResponseEntity<Video> updateTitle(@Valid @PathVariable String videoId,@Valid @PathVariable String title) throws InvalidVideoException {
		return new ResponseEntity<Video>(videoService.updateTitle(videoId, title),HttpStatus.OK);
	}
	@GetMapping("/viewVideosByCategory/{category}")
	public ResponseEntity<List<Video>> viewVideosByCategory(@Valid @PathVariable String category) {
		return new ResponseEntity<List<Video>>(videoService.viewVideosByCategory(category),HttpStatus.OK);
	}
	@GetMapping("viewVideosByInfluencerName/{influencerName}")
	public ResponseEntity<List<Video>> viewVideosByInfluencerName(@Valid @PathVariable String influencerName) {
		return new ResponseEntity<List<Video>>(videoService.viewVideosByInfluencerName(influencerName),HttpStatus.OK);
	}
	@DeleteMapping("/deleteVideo/{videoId}")
	public ResponseEntity<Video> deleteVideo(@Valid @PathVariable String videoId) throws InvalidVideoException{
		return new ResponseEntity<Video>(videoService.deleteVideo(videoId),HttpStatus.OK);
	}

}
