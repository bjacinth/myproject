package com.entities;

import org.hibernate.validator.constraints.Range;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
@Setter
@Getter
@AllArgsConstructor
//Provide necessary Annotation 
@Entity
public class Video {

	// Provide necessary Annotation
	@Id
	@Column(length = 25)
	private String videoId;
	@NotEmpty(message = "Provide value for title ")
	@Column(length = 25)
	private String title;
	@Range(min = 2,max = 10,message = "Duration should be between 2 and 10")
	private double duration ;
	@NotEmpty(message = "Provide value for description")
	@Column(length = 25)
	private String description ;
	@NotEmpty(message = "Provide value for category ")
	@Column(length = 25)
	private String category ;

	// Provide necessary Annotations
	@ManyToOne
	@JoinColumn(name = "influencer_id")
	@JsonBackReference
	private Influencer influencerObj;
	
	public Video() {
		super();
	}
	
}
