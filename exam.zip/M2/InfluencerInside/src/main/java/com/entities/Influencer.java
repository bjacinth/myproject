package com.entities;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
@AllArgsConstructor
//Provide necessary Annotation
@Entity
public class Influencer {

	// Provide necessary Annotation
	@Id
	@Column(length = 25)
	private String influencerId;
	@NotEmpty(message ="Provide value for influencer name")
	@Column(length = 25)
	private String influencerName;
	@NotEmpty(message = "Provide value for platform name")
	@Column(length = 25)
	private String platformName ;
	@PositiveOrZero(message = "Followers count should be 0 or greater")
	@Column(length = 11)
	private int followersCount;
	@NotEmpty(message = "Provide value for expertise")
	@Column(length = 25)
	private String expertise;
	@Positive(message = "Revenue should be greater than 0 ")
	private double revenue;
	
	// Provide necessary Annotations
	@OneToMany(mappedBy = "influencerObj",cascade = CascadeType.ALL)
	@JsonManagedReference
	private List<Video> videoList;

	public Influencer() {
		super();
	}
	
	
}
