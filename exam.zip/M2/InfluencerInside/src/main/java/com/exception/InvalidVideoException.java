package com.exception;

public class InvalidVideoException extends Exception {

	public InvalidVideoException() {
		super();
	}

	

}
