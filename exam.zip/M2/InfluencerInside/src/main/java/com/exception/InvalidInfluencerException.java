package com.exception;

public class InvalidInfluencerException extends Exception  {

	public InvalidInfluencerException() {
		super();
	}

	
 
}
