package com.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.entities.Video;

//Provide necessary annotation
@Repository
public interface VideoRepository extends JpaRepository<Video, String>{
	// Provide necessary methods to view videos by category and influencer name
//	@Query(value = "select v from video.v where v.category =: category")
//	public List<Video> findByVideoByCategory(@Param(value = "category") String category);
//	@Query(value = "select v from video.v where v.influencerName =: influenderName")
//	public List<Video> findByVideoByInfluncerName(@Param(value = "influencerName") String influencerName);
	
	public List<Video> findVideoByCategory(String category);
	
}
