package com.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.entities.Influencer;

//Provide necessary annotation
@Repository
public interface InfluencerRepository extends JpaRepository<Influencer, String>{
//	//Provide necessary methods to view influencer by followers count and get video count for each influencer 
//	@Query(value = "select i from influencer.i where (i.followers_count >: lowerLimit AND i.followers_count <: higherLimit)")
//	List<Influencer> findInfluencerByFollowersCountBetween(@Param(value = "lowerLimit") int lowLimit,@Param(value = "higherLimit") int highLimit);

}
