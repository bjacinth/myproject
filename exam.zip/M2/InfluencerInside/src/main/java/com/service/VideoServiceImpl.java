package com.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entities.Influencer;
import com.entities.Video;
import com.exception.InvalidInfluencerException;
import com.exception.InvalidVideoException;
import com.repository.InfluencerRepository;
import com.repository.VideoRepository;

//Provide necessary annotation
@Service
public class VideoServiceImpl implements IVideoService {

	// Provide necessary annotation
	@Autowired
	private VideoRepository videoRepository;

	// Provide necessary Annotation
	@Autowired
	private InfluencerRepository influencerRepository;

	public Video addVideo(Video video, String influencerId) throws InvalidInfluencerException {
		// fill code
		Influencer inf = influencerRepository.findById(influencerId).orElseThrow(()-> new InvalidInfluencerException());
		video.setInfluencerObj(inf);
		
		return videoRepository.save(video);

	}

	public Video updateTitle(String videoId, String title) throws InvalidVideoException {
		// fill code
		Video vid = videoRepository.findById(videoId).orElseThrow(()-> new InvalidVideoException());
		vid.setTitle(title);
		return vid;

	}

	public List<Video> viewVideosByCategory(String category) {
		// fill code

		return videoRepository.findVideoByCategory(category);
//		return null;
	}

	public List<Video> viewVideosByInfluencerName(String influencerName) {
		// fill code

//		return videoRepository.findVideoByInfluencer_name(influencerName);
		return null;
	}

	public Video deleteVideo(String videoId) throws InvalidVideoException{
		// fill code
		Video vid =  videoRepository.findById(videoId).orElseThrow(()-> new InvalidVideoException());
		videoRepository.delete(vid);
		return vid;

	}

}
