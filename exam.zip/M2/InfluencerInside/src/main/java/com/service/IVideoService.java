package com.service;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;

import com.entities.Video;
import com.exception.InvalidInfluencerException;
import com.exception.InvalidVideoException;

public interface IVideoService {
	
	public Video addVideo( Video video,  String influencerId) throws InvalidInfluencerException;
	public Video updateTitle( String videoId, String title) throws InvalidVideoException;
	public List<Video> viewVideosByCategory ( String category);
	public List<Video> viewVideosByInfluencerName (String influencerName );
	public Video deleteVideo(String videoId) throws InvalidVideoException;
}
