package com.service;

import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.PathVariable;

import com.entities.Influencer;
import com.exception.InvalidVideoException;
import com.exception.InvalidInfluencerException;

public interface IInfluencerService {
    
	public Influencer addInfluencer(Influencer influencer);
	public Influencer appendFollowersCount(String influencerId, int incrementCount) throws InvalidInfluencerException;
	public Influencer viewInfluencerById (String influencerId ) throws InvalidInfluencerException;
	public List<Influencer> viewInfluencersByFollowersCount (int lowLimit, int highLimit);
	public Map<String,Integer> getVideoCountInfluencerwise();
	
}
