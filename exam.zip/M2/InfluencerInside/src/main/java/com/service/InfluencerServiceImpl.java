package com.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entities.Influencer;
import com.repository.InfluencerRepository;
import com.repository.VideoRepository;
import com.exception.InvalidInfluencerException;

//Provide necessary annotation
@Service
public class InfluencerServiceImpl implements IInfluencerService {

	// Provide necessary annotation
	@Autowired
	private InfluencerRepository influencerRepository;

	// Provide necessary Annotation
	@Autowired
	private VideoRepository videoRepository;
	
	public Influencer addInfluencer(Influencer influencer) {
//		// fill code
//		Influencer inf = new Influencer(influencer.getInfluencerId(),influencer.getInfluencerName(),influencer.getPlatformName(),influencer.getFollowersCount(),influencer.getExpertise(),influencer.getRevenue(),null);
//		influencerRepository.save(inf);
		Influencer inf =  influencerRepository.save(influencer);
		return inf;
//		return inf;
	}

	public Influencer appendFollowersCount(String influencerId, int incrementCount) throws InvalidInfluencerException {
		// fill code
		Influencer inf = influencerRepository.findById(influencerId).orElseThrow(()-> new InvalidInfluencerException());
		inf.setFollowersCount(incrementCount);
		
		return inf;

	}

	public Influencer viewInfluencerById(String influencerId) throws InvalidInfluencerException {
		// fill code
		return influencerRepository.findById(influencerId).orElseThrow(()-> new InvalidInfluencerException());

	}

	public List<Influencer> viewInfluencersByFollowersCount(int lowLimit, int highLimit) {
		// fill code

//		return influencerRepository.findInfluencerByFollowersCountBetween(lowLimit, highLimit);
		return null;
	}

	public Map<String, Integer> getVideoCountInfluencerwise() {
		// fill code
		Map<String, Integer> videoCount = new HashMap<>();
		return null;
	}
}
