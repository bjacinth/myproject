import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class PaintingUtil {
    private List<Painting> paintingList = new ArrayList<>();

    public List<Painting> getPaintingList() {
		return paintingList;
	}

	public void setPaintingList(List<Painting> paintingList) {
		this.paintingList = paintingList;
	}

	public void addPaintingDetails(Painting painting) {
        //Fill the code here
		paintingList.add(painting);
    }

    public Painting getPaintingById(String paintingId) {
        //Fill the code here
    	
    	for(Painting p : paintingList) {
    		if(p.getPaintingId()==paintingId) {
    			return p;
    		}
    	}
		return null;
    }

    public List<Painting> getMostValuablePaintings() {
        //Fill the code here
	    
	    Double est = paintingList.stream().max((e1,e2)->Double.compare(e1.getEstimatedWorth(), e2.getEstimatedWorth()))
	    		.map(e -> e.getEstimatedWorth()).get();;
//	    res = paintingList.stream().filter(e -> e.getEstimatedWorth());
	    return paintingList.stream().filter(e -> e.getEstimatedWorth()>= est).toList();
    }

	
	
}