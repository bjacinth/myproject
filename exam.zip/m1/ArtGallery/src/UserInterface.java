import java.util.Scanner;

public class UserInterface {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        //Fill the code here
        System.out.println("Enter the number of paintings to be added");
        int entries = scanner.nextInt();
        scanner.nextLine();
        PaintingUtil paUtil = new PaintingUtil();
        
        System.out.println("Enter painting details");
        String []paint = null;
        for(int i=0;i<entries;i++) {
        	String str = scanner.nextLine();
        	paint = str.split(":");
        	Painting painting = new Painting(paint[0],paint[1],Double.parseDouble(paint[2]),paint[3]);
        	paUtil.addPaintingDetails(painting);
        }
        System.out.println("Enter the painting Id to check worth");
        String pid = scanner.next();
        if(paUtil.getPaintingById(pid)==null) {
        	System.out.println("Painting Id "+pid+" not found");
        }else
        {
            System.out.println(paUtil.getPaintingById(pid));

        }
        if(paUtil.getMostValuablePaintings().isEmpty()) {
        	
        }else
        {
        	System.out.println("Most valuable paintings are");
        	paUtil.getMostValuablePaintings();
        }
        
        
        
    }
}