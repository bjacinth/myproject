public class Garments extends Product {
	public Garments(String productId, String productBarcode,String garmentsName, int noOfGarments, int garmentsPrice) {
		super(productId, productBarcode);
		this.garmentsName = garmentsName;
		this.noOfGarments = noOfGarments;
		this.garmentsPrice = garmentsPrice;
		// TODO Auto-generated constructor stub
	}

	private String garmentsName;
	private int noOfGarments;
	private int garmentsPrice;

	public int getGarmentsPrice() {
		return garmentsPrice;
	}

	public void setGarmentsPrice(int garmentsPrice) {
		this.garmentsPrice = garmentsPrice;
	}

	public String getGarmentsName() {
		return garmentsName;
	}

	public void setGarmentsName(String garmentsName) {
		this.garmentsName = garmentsName;
	}

	public int getNoOfGarments() {
		return noOfGarments;
	}

	public void setNoOfGarments(int noOfGarments) {
		this.noOfGarments = noOfGarments;
	}

	// Include 5 argument Constructor here

	public double getVehicleCharge() {

		// Fill the code here

		return 0;
	}

	public double calculateTotalBill() {

		// Fill the code here

		return 0;
	}

	public double getVehicleCharge(int noOfGarments) {
		// TODO Auto-generated method stub
		if(noOfGarments<1000.00) {
			return 1000.00;
		}
		if(noOfGarments>=1000.00 && noOfGarments<=1800.00) {
			return 2000.00;
		}
		if(noOfGarments>1800.00) {
			return 3000.00;
		}
		return 0.0;
	}

	
	public double calculateTotalBill(int garmentsPrice, int noOfGarments) {
		// TODO Auto-generated method stub
		// Fill the code here
				Double price =(double) (garmentsPrice*noOfGarments);
				Double Tax = price*0.3;
				Double vehicle = getVehicleCharge(noOfGarments);
				Double Totalprice = price+Tax+vehicle;
				
				

				return Totalprice;
		
	}

	@Override
	public double getVehicleCharge(Double weight) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double calculateTotalBill(Double itemPrice, Double weight) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double getVehicleCharge1(int noOfGarments) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double calculateTotalBill1(int noOfGarments, int garmentsPrice) {
		// TODO Auto-generated method stub
		return 0;
	}

}
