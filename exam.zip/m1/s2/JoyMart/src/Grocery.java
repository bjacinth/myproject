public class Grocery extends Product {

	public Grocery(String productId, String productBarcode, String itemName, int weight, int itemPrice) {
		super(productId, productBarcode);
		this.itemName = itemName;
		this.weight = weight;
		this.itemPrice = itemPrice;
		// TODO Auto-generated constructor stub
	}

	private String itemName;
	private int weight;
	private int itemPrice;

	public int getItemPrice() {
		return itemPrice;
	}

	public void setItemPrice(int itemPrice) {
		this.itemPrice = itemPrice;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}

	// Include 5 argument Constructor here

	public double getVehicleCharge(Double weight) {
		// Fill the code here
		double weightfinal = 0;
		if(weight<300.0) {
			weightfinal = 0;
			weightfinal=1000.0;
			return weightfinal;
		}
		if(weight>=300.0 && weight<=600.0) {
			weightfinal = 0;
			weightfinal=2000.0;
			return weightfinal;
		}
		if(weight>600.0) {
			weightfinal = 0;
			weightfinal=3000.0;
			return weightfinal;
		}
		return weightfinal;
	}

	public double calculateTotalBill(Double itemPrice,Double weight) {

		// Fill the code here
		Double price =itemPrice*weight;
		Double Tax = price*0.3;
		Double vehicle = getVehicleCharge(weight);
		Double Totalprice = price+Tax+vehicle;
		
		

		return Totalprice;
	}

	@Override
	public double getVehicleCharge1(int noOfGarments) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double calculateTotalBill1(int noOfGarments, int garmentsPrice) {
		// TODO Auto-generated method stub
		return 0;
	}

	

}
