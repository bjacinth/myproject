import java.util.Scanner;

public class UserInterface {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Utility uti = new Utility();
		
		// Fill the code here
		System.out.println("Enter the Product details");
		String productdetails = sc.next();
		Garments gar = new Garments(null, null, null, 0, 0);
		String[] pro = productdetails.split(":");
		if(uti.validateProductId(pro[0])) {
			System.out.println("The Product Id : "+pro[0]);
			System.out.println("The Product Barcode : "+pro[1]);
			System.out.println("The Item Name : "+pro[3]);
			System.out.println("The Weight per kilo : "+pro[4]);
			System.out.println("The Total Bill : "+uti.parseDetails(productdetails).calculateTotalBill1(gar.getNoOfGarments(),gar.getGarmentsPrice()));
			
		}
		

	}
}