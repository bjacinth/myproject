abstract public class Product {
	protected String productId;
	protected String productBarcode;

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getProductBarcode() {
		return productBarcode;
	}

	public void setProductBarcode(String productBarcode) {
		this.productBarcode = productBarcode;
	}

	public Product(String productId, String productBarcode) {
		super();
		this.productId = productId;
		this.productBarcode = productBarcode;
	}

	// Include 2 argument Constructor here

	// Include abstract methods here
	abstract public double getVehicleCharge(Double weight);
	abstract public double calculateTotalBill(Double itemPrice,Double weight);
	abstract public double getVehicleCharge1(int noOfGarments);
	abstract public double calculateTotalBill1(int noOfGarments,int garmentsPrice);

}
