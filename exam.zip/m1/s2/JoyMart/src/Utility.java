public class Utility {

	public Product parseDetails(String productDetails) {
		Product obj = null;
		

		// Fill the code here
		String [] pro = productDetails.split(":");
		if(pro[2]=="Grocery") {
			Grocery gro = new Grocery(pro[0], pro[1], pro[2],Integer.parseInt(pro[3]) , Integer.parseInt(pro[4]));
			return gro;
		}
		if(pro[2]=="Garments") {
			Garments gar = new Garments(pro[0], pro[1], pro[2],Integer.parseInt(pro[3]) , Integer.parseInt(pro[4]));
			return gar;
		}
		
		return obj;

	}

	public boolean validateProductId(String productId) {
		// Fill the code here
		if(productId.matches("JOY[0-9]{3}[A-Z]")) {
			return true;
		}
		

		return false;
	}
	
	public String findObjectType(Product product) {
	    // Fill the code here
		

		return null;
	}

}
