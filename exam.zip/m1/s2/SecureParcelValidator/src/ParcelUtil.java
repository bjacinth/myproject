import java.util.ArrayList;
import java.util.List;

public class ParcelUtil {

    public boolean validateParcelId(String parcelId) throws InvalidParcelException {
        //Fill the code here
    	if(parcelId.matches("PC-[0-9]{5}")) {
    		String str = parcelId.substring(3,8);
    		if((Integer.parseInt(str) >=10000 && Integer.parseInt(str)<=99999)) {
    			return true;
    		}
    		
    	} else
    	{
    		throw new InvalidParcelException("The parcel Id "+parcelId+" is invalid");
    	}
    	throw new InvalidParcelException("The parcel Id "+parcelId+" is invalid");
    }

    public boolean validateDestination(String destination) throws InvalidParcelException {
        //Fill the code here
    	List<String> city = new ArrayList<String>();
    	city.add("New York");
    	city.add("Los Angeles");
    	city.add("Chicago");
    	city.add("Houston");
    	for(String e:city) {
    		if(destination.equalsIgnoreCase(e)) {
    			return true;
    			
    		}
    		else {
    			throw new InvalidParcelException("The destination "+destination+" is invalid");
    		}
    	}
    	throw new InvalidParcelException("The destination "+destination+" is invalid");
    }

    public boolean validateParcelWeight(double weight, String destination) throws InvalidParcelException {
        //Fill the code here
    	if(destination=="New York") {
    		if(weight<=0 || weight>30.0) {
    			throw new InvalidParcelException("The weight "+weight+" kg is invalid for New York");
    		}
    		else
    		{
    			return true;
    		}
    		
    	}
    	
    	
    	if(destination=="Los Angeles") {
    		if(weight<=0 || weight>50.0) {
    			throw new InvalidParcelException("The weight "+weight+" kg is invalid for Los Angeles");
    		}
    		else
    		{
    			return true;
    		}
    		
    	}
    	if(destination=="Chicago") {
    		if(weight<=0 || weight>25.0) {
    			throw new InvalidParcelException("The weight "+weight+" kg is invalid for Chicago");
    		}
    		else
    		{
    			return true;
    		}
    		
    		
    	}
    	if(destination=="Houston") {
    		if(weight<=0 || weight>40.0) {
    			throw new InvalidParcelException("The weight "+weight+" kg is invalid for Houston");
    		}
    		else
    		{
    			return true;
    		}
    		
    	}
    	throw new InvalidParcelException("The weight "+weight+" kg is invalid for "+destination);
    }
    
    public double calculateShippingCost(String destination, double weight) throws InvalidParcelException {
        //Fill the code here
    	double cost;
    	if(weight<=0) {
    		throw new InvalidParcelException("Invalid weight for "+destination);
    	}
    	else {
    		if(destination == "New York") {
    			cost = weight*10;
    			return cost;
    		}
    		if(destination == "Los Angeles") {
    			cost = weight*8;
    			return cost;
    		}
    		if(destination == "Chicago") {
    			cost = weight*12;
    			return cost;
    		}
    		if(destination == "Houston") {
    			cost = weight*9;
    			return cost;
    		}
    	}
	return -1;
        
    }
}