import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class UserInterface {
    public static void main(String[] args) throws InvalidParcelException {
        Scanner scanner = new Scanner(System.in);
        //Fill the code here
        System.out.println("Enter parcel details");
        ParcelUtil putil = new ParcelUtil();
//        List<String> parcel = new ArrayList<>();
        String  str = scanner.next();
        String [] parcel = str.split(":");
        try {
        	if(putil.validateParcelId(parcel[0])) {
            	if(putil.validateDestination(parcel[1])) {
            		if(putil.validateParcelWeight(Double.parseDouble(parcel[2]), parcel[1])) {
            			putil.calculateShippingCost(parcel[1], Double.parseDouble(parcel[2]));
            		}
            		else {
            			throw new InvalidParcelException("Invalid weight for "+parcel[1]);
            		}
            	}
            	else {
            		throw new InvalidParcelException("The weight "+parcel[2]+" kg is invalid for "+parcel[1]);
            	}
            	
            	
            }
        	else
        	{
        		throw new InvalidParcelException("The parcel Id "+parcel[0]+" is invalid");
        	}
		} catch (Exception e) {
			// TODO: handle exception
			throw new InvalidParcelException(e.getMessage());
		}
        
    }
}