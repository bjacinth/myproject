
public class InvalidParcelException extends Exception {
    

	

	public InvalidParcelException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	
}