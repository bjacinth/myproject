import java.util.Arrays;
import java.util.Scanner;

public class UserInterface {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        //Fill the code here
        String first = scanner.nextLine();
//        if(first.split(" ").length>1) {
//        	System.out.println(first+" is an invalid word");
//        }
        if(first.contains(" ")) {
        	System.out.println(first+" is an invalid word");
        }
        String second = scanner.nextLine();
//        if(first.split(" ").length>1) {
//        	System.out.println(second+" is an invalid word");
//        }
        if(second.contains(" ")) {
        	System.out.println(second+" is an invalid word");
        }
        if(hasAnagraam(second.toLowerCase(),first.toLowerCase())) {
        	System.out.println(opposite(first.toLowerCase()));
        }else{
        	System.out.println(Oppostite2(first, second));
        }
    }
        	
       public static boolean hasAnagraam(String first, String second) {
        	if(first.length()!=second.length()) {
        		return false;
        	}
        	int []first1 = new int[first.length()];
        	for(int i=0;i<first.length();i++) {
        		first1[i] = (int)first.charAt(i);
        	}
        	Arrays.sort(first1);
        	int []second1 = new int[second.length()];
        	for(int i=0;i<second.length();i++) {
        		second1[i] = (int)second.charAt(i);
        	}
        	Arrays.sort(second1);
        	for(int i=0;i<first.length();i++) {
        		if(first1[i]!=second1[i]) {
        			return false;
        		}
        		return true;
        	}
			return false;
       }
        	
        public static String opposite(String word) {
        		StringBuilder build = new StringBuilder(word);
        		for(int i=0;i<build.length();i++) {
        			build.replace(i, i+1, "*");
        		}
        		return build.toString();
        	}
        	public static String Oppostite2(String fiirst,String seecond) {
        		StringBuilder build = new StringBuilder(fiirst+"#"+seecond);
        		build.reverse();
        		
        		for(int i=0;i<build.length();i++) {
        			if(build.charAt(i)=='A'||build.charAt(i)=='a'||build.charAt(i)=='E'||build.charAt(i)=='e'||build.charAt(i)=='I'||build.charAt(i)=='i'||build.charAt(i)=='O'||build.charAt(i)=='o'||build.charAt(i)=='U'||build.charAt(i)=='u')
        				build.replace(i, i+1, "#");
        		}
        		
        		return build.toString();
        	}
    }
        


        
        
        
        

