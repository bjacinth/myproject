package com.eShoppingZone.productservice.resource;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.util.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.eShoppingZone.productservice.entity.Product;
import com.eShoppingZone.productservice.service.ProductService;
import com.fasterxml.jackson.databind.ObjectMapper;

@WebMvcTest(ProductResource.class)
class ProductResourceTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ProductService productService;

    @Test
    void testGetProductById() throws Exception {
        Product product = new Product(1, "Electronics", "Smartphone", "Mobile Phones", new HashMap<>(), new HashMap<>(), List.of("image1.jpg"), 699.99, "A high-end smartphone", new HashMap<>());
        when(productService.getProductById(1)).thenReturn(Optional.of(product));

        mockMvc.perform(get("/product/id/1"))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.productName").value("Smartphone"));
    }
    @Test
    void testAddProduct() throws Exception {
        Product product = new Product(1, "Electronics", "Smartphone", "Mobile Phones", 
            new HashMap<>(), new HashMap<>(), List.of("image1.jpg"), 699.99, 
            "A high-end smartphone", new HashMap<>());

        when(productService.addProducts(any(Product.class))).thenReturn(product);

        mockMvc.perform(post("/product/add")
               .contentType(MediaType.APPLICATION_JSON)
               .content(new ObjectMapper().writeValueAsString(product)))
               .andExpect(status().isCreated()) 
               .andExpect(jsonPath("$.productId").value(1)) 
               .andExpect(jsonPath("$.productName").value("Smartphone"));
    }

//    @Test
//    void testAddProduct() throws Exception {
//        Product product = new Product(1, "Electronics", "Smartphone", "Mobile Phones", new HashMap<>(), new HashMap<>(), List.of("image1.jpg"), 699.99, "A high-end smartphone", new HashMap<>());
//        when(productService.addProducts(any(Product.class))).thenReturn(product);
//
//        mockMvc.perform(post("/product/add")
//               .contentType(MediaType.APPLICATION_JSON)
//               .content(new ObjectMapper().writeValueAsString(product)))
//               .andExpect(status().isOk());
//    }
}