package com.eShoppingZone.productservice.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.eShoppingZone.productservice.entity.Product;
import com.eShoppingZone.productservice.repository.ProductRepository;
//we can also use @ExtendWith(MockitoExtension.class) to handle mocks automatically.
public class ProductServiceImplTest {
	@Mock
	private ProductRepository productRepository;
	@InjectMocks
	private ProductServiceImpl productServiceImpl;
	@BeforeEach
	void setup() {
		MockitoAnnotations.openMocks(this);
	}
	@Test
	void testaddproduct() {
		Product product = new Product(1,"Electronics","SmartPhone","MobilePhone",new HashMap<>(),new HashMap<>(),
				List.of("image.jpg"),699.99,"A high end smartphone",new HashMap<>());
		
		when(productRepository.save(product)).thenReturn(product);
		
		Product savedProduct = (productRepository.save(product));
		assertNotNull(savedProduct);
		assertEquals("SmartPhone", savedProduct.getProductName());
	}
	@Test
    void testGetProductById() {
        Product product = new Product(1, "Electronics", "Smartphone", "Mobile Phones", new HashMap<>(), new HashMap<>(), List.of("image1.jpg"), 699.99, "A high-end smartphone", new HashMap<>());
        when(productRepository.findById(1)).thenReturn(Optional.of(product));

        Optional<Product> foundProduct = productServiceImpl.getProductById(1);
        assertTrue(foundProduct.isPresent());
        assertEquals("Smartphone", foundProduct.get().getProductName());
    }

    @Test
    void testUpdateProduct() {
        Product product = new Product(1, "Electronics", "Smartphone", "Mobile Phones", new HashMap<>(), new HashMap<>(), List.of("image1.jpg"), 699.99, "A high-end smartphone", new HashMap<>());
        when(productRepository.existsById(1)).thenReturn(true);
        when(productRepository.save(product)).thenReturn(product);

        Product updatedProduct = productServiceImpl.updateProducts(product);
        assertNotNull(updatedProduct);
        assertEquals("Smartphone", updatedProduct.getProductName());
    }
    @Test
    void testDeleteProduct() {
        when(productRepository.existsById(1)).thenReturn(true);

        doNothing().when(productRepository).deleteById(1);

        productServiceImpl.deleteProductById(1);

        verify(productRepository, times(1)).deleteById(1);
    }
//    @Test
//    void testDeleteProduct() {
//        doNothing().when(productRepository).deleteById(1);
//        productServiceImpl.deleteProductById(1);
//        verify(productRepository, times(1)).deleteById(1);
//    }

    
}
	
	
	
	

