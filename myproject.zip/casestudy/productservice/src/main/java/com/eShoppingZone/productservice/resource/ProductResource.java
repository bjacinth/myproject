package com.eShoppingZone.productservice.resource;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.eShoppingZone.productservice.entity.Product;
import com.eShoppingZone.productservice.service.ProductService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/product")
@CrossOrigin(origins = "http://localhost:3000")
public class ProductResource {
	@Autowired
	private ProductService productService;

	public ProductResource(ProductService productService) {
		super();
		this.productService = productService;
	}

	public ProductResource() {
		super();
		// TODO Auto-generated constructor stub
	}
	@PostMapping("/add")
	public ResponseEntity<Product> addProduct(@Valid @RequestBody Product product) {
	    Product savedProduct = productService.addProducts(product);
	    return new ResponseEntity<>(savedProduct, HttpStatus.CREATED);
	}
//	
//	@PostMapping("/add")
//	public ResponseEntity<Product> addProduct(@Valid @RequestBody Product product) {
//	    Product savedProduct = productService.addProducts(product);
//	    return new ResponseEntity<>(savedProduct, HttpStatus.CREATED);
//	}
	@GetMapping("/all")
	public ResponseEntity<List<Product>> getAllProducts(){
		return ResponseEntity.ok(productService.getAllProducts());
	}
	@GetMapping("/id/{productId}")
	public ResponseEntity<Product> getProductById(@PathVariable int productId){
		return productService.getProductById(productId)
				.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
	}
	@GetMapping("/type/{productType}")
	public ResponseEntity<List<Product>> getProductByType(@PathVariable String productType){
		return ResponseEntity.ok(productService.getProductByType(productType));
	}
	@GetMapping("/category/{category}")
	public ResponseEntity<List<Product>> getProductByCategory(@PathVariable String category){
		return ResponseEntity.ok(productService.getProductByCategory(category));
	}
	@PutMapping("/update")
	public ResponseEntity<Product> updateProducts(@RequestBody Product product) {
	    Product updatedProduct = productService.updateProducts(product);
	    return ResponseEntity.ok(updatedProduct);
	}
	@DeleteMapping("/{productId}")
	public void deleteProduct(@PathVariable int productId) {
		productService.deleteProductById(productId);
	}
	
	
}
