package com.eShoppingZone.productservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.eShoppingZone.productservice.entity.Product;
import com.eShoppingZone.productservice.exception.ProductNotFoundException;
import com.eShoppingZone.productservice.repository.ProductRepository;
@Service
public class ProductServiceImpl implements ProductService{
	

	public ProductServiceImpl() {
		super();
	}
	@Autowired
	private ProductRepository productRepository;

	@Override
	public Product addProducts(Product product) {
		// TODO Auto-generated method stub
		return productRepository.save(product);
	}

	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return productRepository.findAll();
	}

	@Override
	public Optional<Product> getProductById(int productId) {
		// TODO Auto-generated method stub
		return productRepository.findById(productId);
	}

	@Override
	public Optional<Product> getProductByName(String productName) {
		// TODO Auto-generated method stub
		return productRepository.findByProductName(productName);
	}

	@Override
	public Product updateProducts(Product product) {
		// TODO Auto-generated method stub
		if(!productRepository.existsById(product.getProductId())) {
			throw new ProductNotFoundException("Product not found with productId: "+product.getProductId());
		}
		return productRepository.save(product);
	}

	@Override
	public void deleteProductById(int productId) {
		// TODO Auto-generated method stub
		if(!productRepository.existsById(productId)) {
			throw new ProductNotFoundException("Product not found with productId: "+productId);
		}
		productRepository.deleteById(productId);
	}

	@Override
	public List<Product> getProductByCategory(String category) {
		// TODO Auto-generated method stub
		return productRepository.findByCategory(category);
	}

	@Override
	public List<Product> getProductByType(String ProductType) {
		// TODO Auto-generated method stub
		return productRepository.findByProductType(ProductType);
	}

}
