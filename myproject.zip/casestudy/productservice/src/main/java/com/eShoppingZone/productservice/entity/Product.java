package com.eShoppingZone.productservice.entity;

import java.util.List;
import java.util.Map;
import java.util.Objects;

import jakarta.persistence.Access;
import jakarta.persistence.AccessType;
import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.MapKeyColumn;
import jakarta.validation.constraints.NotNull;
@Entity
public class Product {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
//	@NotNull(message = "productId should not be null")
	private int productId;
//	@NotNull(message = "productType should not be blank")
	private String productType;
//	@NotNull(message = "productName ahould not be blank")
	private String productName;
//	@NotNull(message = "category should not be blank")
	private String category;
	@ElementCollection
	@CollectionTable(name = "product_rating", joinColumns = @JoinColumn(name = "productId"))
    @MapKeyColumn(name = "user_id")
    @Column(name = "rating")
	private Map<Integer, Double> rating;
	@ElementCollection
	@CollectionTable(name = "product_review", joinColumns = @JoinColumn(name = "productId"))
    @MapKeyColumn(name = "user_id")
    @Column(name = "review")
	private Map<Integer, String> review;
	@ElementCollection
//	@NotNull(message = "image list should not be blank")
	private List<String> image;
//	@NotNull(message = "price must be positive and not null")
	private Double price;
//	@NotNull(message = "description should not be blank")
	private String description;
	@ElementCollection
    @CollectionTable(name = "product_specification", joinColumns = @JoinColumn(name = "productId"))
    @MapKeyColumn(name = "spec_key")
    @Column(name = "spec_value")
	private Map<String, String> specification;
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Product(int productId, String productType, String productName, String category, Map<Integer, Double> rating,
			Map<Integer, String> review, List<String> image, Double price, String description,
			Map<String, String> specification) {
		super();
		this.productId = productId;
		this.productType = productType;
		this.productName = productName;
		this.category = category;
		this.rating = rating;
		this.review = review;
		this.image = image;
		this.price = price;
		this.description = description;
		this.specification = specification;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public Map<Integer, Double> getRating() {
		return rating;
	}
	public void setRating(Map<Integer, Double> rating) {
		this.rating = rating;
	}
	public Map<Integer, String> getReview() {
		return review;
	}
	public void setReview(Map<Integer, String> review) {
		this.review = review;
	}
	public List<String> getImage() {
		return image;
	}
	public void setImage(List<String> image) {
		this.image = image;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Map<String, String> getSpecification() {
		return specification;
	}
	public void setSpecification(Map<String, String> specification) {
		this.specification = specification;
	}
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", ProductType=" + productType + ", productName=" + productName
				+ ", category=" + category + ", rating=" + rating + ", review=" + review + ", image=" + image
				+ ", price=" + price + ", description=" + description + ", specification=" + specification
				+ ", getProductId()=" + getProductId() + ", getProductType()=" + getProductType()
				+ ", getProductName()=" + getProductName() + ", getCategory()=" + getCategory() + ", getRating()="
				+ getRating() + ", getReview()=" + getReview() + ", getImage()=" + getImage() + ", getPrice()="
				+ getPrice() + ", getDescription()=" + getDescription() + ", getSpecification()=" + getSpecification()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
				+ "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(productType, category, description, image, price, productId, productName, rating, review,
				specification);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Product other = (Product) obj;
		return Objects.equals(productType, other.productType) && Objects.equals(category, other.category)
				&& Objects.equals(description, other.description) && Objects.equals(image, other.image)
				&& Objects.equals(price, other.price) && productId == other.productId
				&& Objects.equals(productName, other.productName) && Objects.equals(rating, other.rating)
				&& Objects.equals(review, other.review) && Objects.equals(specification, other.specification);
	}
	

}
