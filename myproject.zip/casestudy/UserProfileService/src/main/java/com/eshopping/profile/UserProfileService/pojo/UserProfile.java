package com.eshopping.profile.UserProfileService.pojo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.CollectionTable;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.*;
@Entity
@Table(name = "user_profiles")
public class UserProfile {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer profileId;
//	@NotBlank(message = "fullName should not be empty" )
	private String fullName;
	
	private String image;
//	@Email(message = "Invalid email")
//	@NotBlank(message = "Email should not be empty")
	private String emailId;
//	@NotNull(message = "Mobile Number should not be empty")
//	@Pattern(regexp = "^\\d{10}",message = "Mobile number should be 10 digits")
//	@Min(value = 1000000000L, message = "Mobile number should be exactly 10 digits")
//	@Max(value = 9999999999L, message = "Mobile number should be exactly 10 digits")
	private String mobileNumber;
	@OneToMany(cascade = CascadeType.ALL , orphanRemoval = true)
	@JoinColumn(name = "profile_id")
	private List<Address> address = new ArrayList<>();
	private String about;
	private LocalDate dateOfBirth;
	private String gender;
//	@NotNull(message = "Role is required")

	@Enumerated(EnumType.STRING)
	private Role role;
//	@NotBlank(message = "Password cannot be empty")
	private String password;
//	@Id
//	@GeneratedValue(strategy = GenerationType.AUTO)
//	private Integer walletId;

	
	
	public UserProfile() {
		super();
		// TODO Auto-generated constructor stub
	}



	public UserProfile(Integer profileId, @NotBlank(message = "fullName should not be empty") String fullName, String image,
			@Email(message = "Invalid email") @NotBlank(message = "Emsil should not be empty") String emailId,
			@NotNull(message = "Mobile Number should not be empty") @Min(value = 1000000000, message = "Mobile number should be exactly 10 digits") @Max(value = 999999999, message = "Mobile number should be exactly 10 digits") String mobileNumber,
			List<Address> address, String about, LocalDate dateOfBirth, String gender,
			@NotNull(message = "Role is required") Role role,
			@NotBlank(message = "Password cannot be empty") String password) {
		super();
		this.profileId = profileId;
		this.fullName = fullName;
		this.image = image;
		this.emailId = emailId;
		this.mobileNumber = mobileNumber;
		this.address = address;
		this.about = about;
		this.dateOfBirth = dateOfBirth;
		this.gender = gender;
		this.role = role;
		this.password = password;
//		this.walletId = walletId;
	}



	public Integer getProfileId() {
		return profileId;
	}



	public void setProfileId(Integer profileId) {
		this.profileId = profileId;
	}



	public String getFullName() {
		return fullName;
	}



	public void setFullName(String fullName) {
		this.fullName = fullName;
	}



	public String getImage() {
		return image;
	}



	public void setImage(String image) {
		this.image = image;
	}



	public String getEmailId() {
		return emailId;
	}



	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}



	public String getMobileNumber() {
		return mobileNumber;
	}



	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}



	public List<Address> getAddress() {
		return address;
	}



	public void setAddress(List<Address> address) {
		this.address = address;
	}



	public String getAbout() {
		return about;
	}



	public void setAbout(String about) {
		this.about = about;
	}



	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}



	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}



	public String getGender() {
		return gender;
	}



	public void setGender(String gender) {
		this.gender = gender;
	}



	public Role getRole() {
		return role;
	}



	public void setRole(Role role) {
		this.role = role;
	}



	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "UserProfile [profileId=" + profileId + ", fullName=" + fullName + ", image=" + image + ", emailId="
				+ emailId + ", mobileNumber=" + mobileNumber + ", address=" + address + ", about=" + about
				+ ", dateOfBirth=" + dateOfBirth + ", gender=" + gender + ", role=" + role + ", password=" + password
				+ "]";
	}

//
//	public Integer getWalletId() {
//		return walletId;
//	}
//
//
//
//	public void setWalletId(Integer walletId) {
//		this.walletId = walletId;
//	}
	
	
	

}
