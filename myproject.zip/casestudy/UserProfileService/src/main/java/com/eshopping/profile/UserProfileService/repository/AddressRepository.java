package com.eshopping.profile.UserProfileService.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.eshopping.profile.UserProfileService.pojo.Address;

@Repository
public interface AddressRepository extends JpaRepository<Address, Integer> {

}
	