package com.eshopping.profile.UserProfileService.resource;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.eshopping.profile.UserProfileService.exception.UserNotFoundException;
import com.eshopping.profile.UserProfileService.pojo.Address;
import com.eshopping.profile.UserProfileService.pojo.UserProfile;
import com.eshopping.profile.UserProfileService.repository.AddressRepository;
import com.eshopping.profile.UserProfileService.service.ProfileService;

@RestController
@RequestMapping("/profile")
@CrossOrigin(origins = "http://localhost:3000")
public class ProfileResource {

    @Autowired
    private ProfileService profileService;
    @Autowired
    private AddressRepository addressRepository;

    public ProfileResource(ProfileService profileService) {
        this.profileService = profileService;
    }

    public ProfileResource() {}

    @PostMapping("/addCustomer")
    public ResponseEntity<UserProfile> addNewCustomerProfile(@RequestBody UserProfile userProfile) {
        UserProfile profile = profileService.addNewCustomerProfile(userProfile);
        return new ResponseEntity<>(profile, HttpStatus.CREATED);
    }

    @GetMapping("/all")
    public ResponseEntity<List<UserProfile>> getAllProfiles() {
        List<UserProfile> profiles = profileService.getAllProfiles();
        return ResponseEntity.ok(profiles);
    }

    @GetMapping("/id/{profileId}")
    public ResponseEntity<Optional<UserProfile>> getByProfileId(@PathVariable Integer profileId) {
        Optional<UserProfile> profile = profileService.getByProfileId(profileId);
        if (profile == null) {
            throw new UserNotFoundException("User with ID " + profileId + " not found.");
        }
        return ResponseEntity.ok(profile);
    }

    @PutMapping("/update")
    public ResponseEntity<UserProfile> updateProfile(@RequestBody UserProfile updateProfile) {
        UserProfile updatedProfile = profileService.updateProfile(updateProfile);
        return ResponseEntity.ok(updatedProfile);
    }

    @DeleteMapping("/delete/{profileId}")
    public ResponseEntity<String> deleteProfile(@PathVariable Integer profileId) {
        profileService.DeleteProfile(profileId);
        return ResponseEntity.ok("Profile deleted successfully.");
    }

    @PostMapping("/addMerchant")
    public ResponseEntity<UserProfile> addNewMerchantProfile(@RequestBody UserProfile userProfile) {
        return ResponseEntity.ok(profileService.addNewMerchantProfile(userProfile));
    }

    @PostMapping("/addDeliveryAgent")
    public ResponseEntity<UserProfile> addNewDeliveryProfile(@RequestBody UserProfile userProfile) {
        return ResponseEntity.ok(profileService.addNewDeliveryProfile(userProfile));
    }

    @GetMapping("/{mobileNumber}")
    public ResponseEntity<UserProfile> findByMobileNo(@PathVariable String mobileNumber) {
        UserProfile profile = profileService.findByMobileNo(mobileNumber);
        if (profile == null) {
            throw new UserNotFoundException("User with mobile number " + mobileNumber + " not found.");
        }
        return ResponseEntity.ok(profile);
    }

    @GetMapping("/name/{fullName}")
    public ResponseEntity<UserProfile> getByUserName(@PathVariable String fullName) {
        UserProfile profile = profileService.findByFullName(fullName);
        if (profile == null) {
            throw new UserNotFoundException("User with name " + fullName + " not found.");
        }
        return ResponseEntity.ok(profile);
    }
    @GetMapping("/address/{profileId}")
    public List<Address> getAddressByProfileId(@PathVariable int profileId) {
    	return profileService.getAddressByProfileId(profileId);
    }
    
    @PostMapping("address/add/{profileId}")
    public Address addAddress(@RequestBody Address address,@PathVariable Integer profileId) {
    	return profileService.addAddress(address, profileId);
    }
    
    @GetMapping("/emailId/{emailId}")
    public UserProfile getByEmail(@PathVariable String emailId) {
    	return profileService.getByEmail(emailId);
    }
}
