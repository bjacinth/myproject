package com.eshopping.profile.UserProfileService.pojo;

public enum Role {
    Customer,
    Merchant,
    DeliveryAgent
    }
