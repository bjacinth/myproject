package com.eshopping.profile.UserProfileService.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.eshopping.profile.UserProfileService.exception.UserNotFoundException;
import com.eshopping.profile.UserProfileService.pojo.Address;
import com.eshopping.profile.UserProfileService.pojo.UserProfile;
import com.eshopping.profile.UserProfileService.repository.AddressRepository;
import com.eshopping.profile.UserProfileService.repository.ProfileRepository;

@Service
public class ProfileServiceImpl implements ProfileService {
    private static final Logger logger = LoggerFactory.getLogger(ProfileServiceImpl.class);

    @Autowired
    private ProfileRepository profileRepository;
    @Autowired
    private AddressRepository addressRepository;
    

    public ProfileServiceImpl(ProfileRepository profileRepository) {
        super();
        this.profileRepository = profileRepository;
    }

    public ProfileServiceImpl() {
        super();
    }

    @Override
    public UserProfile addNewCustomerProfile(UserProfile userProfile) {
        logger.info("Adding new customer profile: {}", userProfile);
        return profileRepository.save(userProfile);
    }

    @Override
    public List<UserProfile> getAllProfiles() {
        logger.info("Fetching all profiles");
        return profileRepository.findAll();
    }

    @Override
    public Optional<UserProfile> getByProfileId(Integer profileId) {
        logger.info("Fetching profile by ID: {}", profileId);
        Optional<UserProfile> userProfile = profileRepository.findById(profileId);
        if (userProfile == null) {
            logger.error("User with ID {} not found", profileId);
            throw new UserNotFoundException("User with ID " + profileId + " not found");
        }
        return userProfile;
    }

    @Override
    public UserProfile updateProfile(UserProfile updateProfile) {
        logger.info("Updating profile: {}", updateProfile);
        if (!profileRepository.existsById(updateProfile.getProfileId())) {
            logger.error("User with ID {} not found", updateProfile.getProfileId());
            throw new UserNotFoundException("User with ID " + updateProfile.getProfileId() + " not found");
        }
        return profileRepository.save(updateProfile);
    }

    @Override
    public void DeleteProfile(Integer profileId) {
        logger.info("Deleting profile with ID: {}", profileId);
        if (!profileRepository.existsById(profileId)) {
            logger.error("User with ID {} not found", profileId);
            throw new UserNotFoundException("User with ID " + profileId + " not found");
        }
        profileRepository.deleteById(profileId);
    }

    @Override
    public UserProfile addNewMerchantProfile(UserProfile userProfile) {
        logger.info("Adding new merchant profile: {}", userProfile);
        return profileRepository.save(userProfile);
    }

    @Override
    public UserProfile addNewDeliveryProfile(UserProfile userProfile) {
        logger.info("Adding new delivery profile: {}", userProfile);
        return profileRepository.save(userProfile);
    }

    @Override
    public UserProfile findByMobileNo(String mobileNumber) {
        logger.info("Fetching profile by mobile number: {}", mobileNumber);
        return profileRepository.findByMobileNumber(mobileNumber);
    }

    @Override
    public UserProfile findByFullName(String fullName) {
        logger.info("Fetching profile by full name: {}", fullName);
        return profileRepository.findByFullName(fullName);
    }

	@Override
	public List<Address> getAddressByProfileId(Integer profileId) {
		// TODO Auto-generated method stub
		return profileRepository.findById(profileId).get().getAddress();
	}
	@Override
	public Address addAddress(Address address,Integer profileId) {
		UserProfile userProfile = profileRepository.findById(profileId).orElse(null);
		userProfile.getAddress().add(address);
		profileRepository.save(userProfile);
		return address;
		
	}
	@Override
	public UserProfile getByEmail(String emailId) {
		
		return profileRepository.findByEmailId(emailId);
		
	}

	

	
}
