package com.eshopping.profile.UserProfileService.exception;

public class InvalidUserProfileException extends RuntimeException{
	
	public InvalidUserProfileException(String message) {
		super(message);
	}

}
