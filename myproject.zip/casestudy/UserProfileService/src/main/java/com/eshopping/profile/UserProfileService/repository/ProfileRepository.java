package com.eshopping.profile.UserProfileService.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.eshopping.profile.UserProfileService.pojo.UserProfile;
@Repository
public interface ProfileRepository extends JpaRepository<UserProfile,Integer>{
	
	UserProfile findById(int profileId);
	
	UserProfile findByMobileNumber(String mobileNumber);
	
	UserProfile findByFullName(String fullName);
	
	UserProfile findByEmailId(String emailId);

}