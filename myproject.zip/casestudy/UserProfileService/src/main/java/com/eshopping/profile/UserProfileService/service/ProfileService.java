package com.eshopping.profile.UserProfileService.service;

import java.util.List;
import java.util.Optional;

import com.eshopping.profile.UserProfileService.pojo.Address;
import com.eshopping.profile.UserProfileService.pojo.UserProfile;

public interface ProfileService {
	
	UserProfile addNewCustomerProfile(UserProfile userProfile);
	
	List<UserProfile> getAllProfiles();
	
	Optional<UserProfile> getByProfileId(Integer profileId);
	
	UserProfile updateProfile(UserProfile updateProfile);
	
	void DeleteProfile(Integer profileId);
	
	UserProfile addNewMerchantProfile(UserProfile userProfile);
	
	UserProfile addNewDeliveryProfile(UserProfile userProfile);
	
	UserProfile findByMobileNo(String mobileNumber);
	
	UserProfile findByFullName(String fullName);
	
	List<Address> getAddressByProfileId(Integer profileId);

	Address addAddress(Address address, Integer profileId);

	UserProfile getByEmail(String emailId);


}
