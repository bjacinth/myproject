package com.eshopping.profile.UserProfileService.service;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.eshopping.profile.UserProfileService.exception.UserNotFoundException;
import com.eshopping.profile.UserProfileService.pojo.Address;
import com.eshopping.profile.UserProfileService.pojo.UserProfile;
import com.eshopping.profile.UserProfileService.repository.ProfileRepository;
@ExtendWith(MockitoExtension.class)
class ProfileServiceImplTest {

    @Mock
    private ProfileRepository profileRepository;

    @InjectMocks
    private ProfileServiceImpl profileService;

    private UserProfile userProfile;

    @BeforeEach
    void setUp() {
        userProfile = new UserProfile();
        userProfile.setProfileId(1);
        userProfile.setFullName("John Doe");
        userProfile.setMobileNumber("1234567890");
    }

    @Test
    void testAddNewCustomerProfile() {
        when(profileRepository.save(userProfile)).thenReturn(userProfile);
        UserProfile savedProfile = profileService.addNewCustomerProfile(userProfile);
        assertNotNull(savedProfile);
        assertEquals(userProfile.getFullName(), savedProfile.getFullName());
    }

    @Test
    void testGetAllProfiles() {
        when(profileRepository.findAll()).thenReturn(Arrays.asList(userProfile));
        List<UserProfile> profiles = profileService.getAllProfiles();
        assertFalse(profiles.isEmpty());
        assertEquals(1, profiles.size());
    }

    @Test
    void testGetByProfileId_Success() {
    	doReturn(Optional.of(userProfile)).when(profileRepository).findById(1);

        Optional<UserProfile> foundProfile = profileService.getByProfileId(1);
        assertTrue(foundProfile.isPresent());
        assertEquals(userProfile.getProfileId(), foundProfile.get().getProfileId());
    }

    @Test
    void testGetByProfileId_NotFound() {
        when(profileRepository.findById(1)).thenReturn(userProfile);
        assertThrows(UserNotFoundException.class, () -> profileService.getByProfileId(1));
    }

    @Test
    void testUpdateProfile_Success() {
        when(profileRepository.existsById(userProfile.getProfileId())).thenReturn(true);
        when(profileRepository.save(userProfile)).thenReturn(userProfile);
        UserProfile updatedProfile = profileService.updateProfile(userProfile);
        assertNotNull(updatedProfile);
    }

    @Test
    void testUpdateProfile_NotFound() {
        when(profileRepository.existsById(userProfile.getProfileId())).thenReturn(false);
        assertThrows(UserNotFoundException.class, () -> profileService.updateProfile(userProfile));
    }

    @Test
    void testDeleteProfile_Success() {
        when(profileRepository.existsById(1)).thenReturn(true);
        doNothing().when(profileRepository).deleteById(1);
        profileService.DeleteProfile(1);
        verify(profileRepository, times(1)).deleteById(1);
    }

    @Test
    void testDeleteProfile_NotFound() {
        when(profileRepository.existsById(1)).thenReturn(false);
        assertThrows(UserNotFoundException.class, () -> profileService.DeleteProfile(1));
    }

    @Test
    void testFindByMobileNo() {
        when(profileRepository.findByMobileNumber("1234567890")).thenReturn(userProfile);
        UserProfile foundProfile = profileService.findByMobileNo("1234567890");
        assertNotNull(foundProfile);
        assertEquals(userProfile.getMobileNumber(), foundProfile.getMobileNumber());
    }

    @Test
    void testFindByFullName() {
        when(profileRepository.findByFullName("John Doe")).thenReturn(userProfile);
        UserProfile foundProfile = profileService.findByFullName("John Doe");
        assertNotNull(foundProfile);
        assertEquals(userProfile.getFullName(), foundProfile.getFullName());
    }

    @Test
    void testGetAddressByProfileId() {
        Address address = new Address();
        address.setStreetName("123 Main St");
        userProfile.setAddress(Arrays.asList(address));

        doReturn(Optional.of(userProfile)).when(profileRepository).findById(1);

        List<Address> addresses = profileService.getAddressByProfileId(1);
        assertFalse(addresses.isEmpty());
        assertEquals("123 Main St", addresses.get(0).getStreetName());
    }
}