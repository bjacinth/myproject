package com.eshopping.profile.UserProfileService.resource;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import com.eshopping.profile.UserProfileService.exception.UserNotFoundException;
import com.eshopping.profile.UserProfileService.pojo.Address;
import com.eshopping.profile.UserProfileService.pojo.UserProfile;
import com.eshopping.profile.UserProfileService.service.ProfileService;

@ExtendWith(MockitoExtension.class)
class ProfileResourceTest {

    @Mock
    private ProfileService profileService;

    @InjectMocks
    private ProfileResource profileResource;

    private UserProfile userProfile;

    @BeforeEach
    void setUp() {
        userProfile = new UserProfile();
        userProfile.setProfileId(1);
        userProfile.setFullName("John Doe");
        userProfile.setMobileNumber("1234567890");
    }

    @Test
    void testAddNewCustomerProfile() {
        when(profileService.addNewCustomerProfile(userProfile)).thenReturn(userProfile);
        ResponseEntity<UserProfile> response = profileResource.addNewCustomerProfile(userProfile);
        assertNotNull(response.getBody());
        assertEquals(201, response.getStatusCodeValue());
    }

    @Test
    void testGetAllProfiles() {
        when(profileService.getAllProfiles()).thenReturn(Arrays.asList(userProfile));
        ResponseEntity<List<UserProfile>> response = profileResource.getAllProfiles();
        assertFalse(response.getBody().isEmpty());
        assertEquals(1, response.getBody().size());
    }

    @Test
    void testGetByProfileId_Success() {
        when(profileService.getByProfileId(1)).thenReturn(Optional.of(userProfile));
        ResponseEntity<Optional<UserProfile>> response = profileResource.getByProfileId(1);
        assertTrue(response.getBody().isPresent());
    }

    @Test
    void testGetByProfileId_NotFound() {
        when(profileService.getByProfileId(1)).thenThrow(new UserNotFoundException("User not found"));
        assertThrows(UserNotFoundException.class, () -> profileResource.getByProfileId(1));
    }

    @Test
    void testUpdateProfile() {
        when(profileService.updateProfile(userProfile)).thenReturn(userProfile);
        ResponseEntity<UserProfile> response = profileResource.updateProfile(userProfile);
        assertNotNull(response.getBody());
    }

    @Test
    void testDeleteProfile() {
        doNothing().when(profileService).DeleteProfile(1);
        ResponseEntity<String> response = profileResource.deleteProfile(1);
        assertEquals("Profile deleted successfully.", response.getBody());
    }

    @Test
    void testFindByMobileNo_Success() {
        when(profileService.findByMobileNo("1234567890")).thenReturn(userProfile);
        ResponseEntity<UserProfile> response = profileResource.findByMobileNo("1234567890");
        assertNotNull(response.getBody());
    }

    @Test
    void testFindByMobileNo_NotFound() {
        when(profileService.findByMobileNo("1234567890")).thenThrow(new UserNotFoundException("User not found"));
        assertThrows(UserNotFoundException.class, () -> profileResource.findByMobileNo("1234567890"));
    }

    @Test
    void testFindByFullName() {
        when(profileService.findByFullName("John Doe")).thenReturn(userProfile);
        ResponseEntity<UserProfile> response = profileResource.getByUserName("John Doe");
        assertNotNull(response.getBody());
    }

    @Test
    void testGetAddressByProfileId() {
        Address address = new Address();
        address.setStreetName("123 Main St");
        userProfile.setAddress(Arrays.asList(address));

        when(profileService.getAddressByProfileId(1)).thenReturn(userProfile.getAddress());
        List<Address> addresses = profileResource.getAddressByProfileId(1);
        assertFalse(addresses.isEmpty());
        assertEquals("123 Main St", addresses.get(0).getStreetName());
    }
}
