package com.order.orderservice.orders;

import java.time.LocalDate;
import java.util.List;

import com.order.orderservice.cart.Items;
import com.order.orderservice.orders.address.Address;

import jakarta.persistence.CascadeType;
import jakarta.persistence.CollectionTable;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
@Entity
public class Orders {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int orderId;
	private LocalDate orderDate;
	private int profileId;
	private Double ammountPaid;
	private String modeOfPayment;
	private String orderStatus;
	private int quantity;
	private String paymentId; // Razorpay payment ID

	@OneToOne(cascade = CascadeType.ALL,orphanRemoval = true)
	@JoinColumn(name = "order_id")
	private Address address;
	@OneToMany(cascade = CascadeType.ALL,orphanRemoval = true)
	@JoinColumn(name = "order_id")
	private List<OrderItem> items;
	public Orders() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Orders(int orderId, LocalDate orderDate, int profileId, Double ammountPaid, String modeOfPayment,
			String orderStatus, int quantity, Address address, List<OrderItem> items) {
		super();
		this.orderId = orderId;
		this.orderDate = orderDate;
		this.profileId = profileId;
		this.ammountPaid = ammountPaid;
		this.modeOfPayment = modeOfPayment;
		this.orderStatus = orderStatus;
		this.quantity = quantity;
		this.address = address;
		this.items = items;
	}

	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public LocalDate getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}
	public int getProfileId() {
		return profileId;
	}
	public void setProfileId(int profileId) {
		this.profileId = profileId;
	}
	public Double getAmmountPaid() {
		return ammountPaid;
	}
	public void setAmmountPaid(Double ammountPaid) {
		this.ammountPaid = ammountPaid;
	}
	public String getModeOfPayment() {
		return modeOfPayment;
	}
	public void setModeOfPayment(String modeOfPayment) {
		this.modeOfPayment = modeOfPayment;
	}
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	
	public List<OrderItem> getItems() {
		return items;
	}

	public void setItems(List<OrderItem> items) {
		this.items = items;
	}


	public String getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(String paymentId) {
		this.paymentId = paymentId;
	}

	public Orders(int orderId, LocalDate orderDate, int profileId, Double ammountPaid, String modeOfPayment,
			String orderStatus, int quantity, String paymentId, Address address, List<OrderItem> items) {
		super();
		this.orderId = orderId;
		this.orderDate = orderDate;
		this.profileId = profileId;
		this.ammountPaid = ammountPaid;
		this.modeOfPayment = modeOfPayment;
		this.orderStatus = orderStatus;
		this.quantity = quantity;
		this.paymentId = paymentId;
		this.address = address;
		this.items = items;
	}

	@Override
	public String toString() {
		return "Orders [orderId=" + orderId + ", orderDate=" + orderDate + ", profileId=" + profileId + ", ammountPaid="
				+ ammountPaid + ", modeOfPayment=" + modeOfPayment + ", orderStatus=" + orderStatus + ", quantity="
				+ quantity + ", paymentId=" + paymentId + ", address=" + address + ", items=" + items + "]";
	}
	
	
}