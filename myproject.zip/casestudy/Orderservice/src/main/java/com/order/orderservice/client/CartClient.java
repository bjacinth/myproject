package com.order.orderservice.client;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.order.orderservice.cart.Cart;

@FeignClient(name = "CARTSERVICE") 
public interface CartClient {
    @GetMapping("/cart/{profileId}")
    Cart getCartByProfileId(@PathVariable("profileId") int profileId);
}

