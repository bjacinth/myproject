package com.order.orderservice.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.order.orderservice.wallet.Ewallet;


@FeignClient(name = "WALLETSERVICE")
public interface WalletClient {
//    @PutMapping("/wallet/update/{profileId}/{amount}/{transactionRemarks}/{transactionType}")
//    Double updateWallet(@PathVariable Integer profileId, @PathVariable Double amount,@PathVariable String transactionRemarks,@PathVariable String transactionType);
    
    @GetMapping("/wallet/profileId/{profileId}")
    public Ewallet getWalletByProfileId(@PathVariable Integer profileId);
    

    @PutMapping("/wallet/update/{profileId}/{amount}/{transactionRemarks}/{transactionType}")
    public void updateWallet(@PathVariable("profileId") Integer profileId,@PathVariable("amount") Double amount,
    @PathVariable("transactionRemarks") String transactionRemarks,@PathVariable("transactionType") String transactionType);

}
