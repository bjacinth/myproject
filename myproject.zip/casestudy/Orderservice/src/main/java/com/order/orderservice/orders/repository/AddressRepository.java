package com.order.orderservice.orders.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.order.orderservice.orders.address.Address;
@EnableJpaRepositories
public interface AddressRepository extends JpaRepository<Address, Integer>{
	
	List<Address> findByProfileId(Integer customerId);

}
