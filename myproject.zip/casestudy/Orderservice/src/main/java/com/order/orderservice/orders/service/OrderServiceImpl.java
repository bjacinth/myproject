package com.order.orderservice.orders.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import com.order.orderservice.cart.Cart;
import com.order.orderservice.cart.Items;
import com.order.orderservice.client.CartClient;
import com.order.orderservice.client.WalletClient;
import com.order.orderservice.orders.OrderItem;
import com.order.orderservice.orders.Orders;
import com.order.orderservice.orders.address.Address;
import com.order.orderservice.orders.repository.AddressRepository;
import com.order.orderservice.orders.repository.OrderRepository;
import com.order.orderservice.wallet.Ewallet;
import com.razorpay.PaymentLink;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;

@Service
public class OrderServiceImpl implements OrderService {

    private static final Logger logger = LoggerFactory.getLogger(OrderServiceImpl.class);

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private AddressRepository addressRepository;

    
    @Autowired
    private WalletClient walletClient;

    @Override
    public Orders placeOrder(Orders order) {
        System.out.println("service " + order);

        // Set order date
        order.setOrderDate(LocalDate.now());

        // Convert Items to OrderItem
        List<OrderItem> orderItems = new ArrayList<>();
        for (OrderItem cartItem : order.getItems()) {
            OrderItem orderItem = new OrderItem();
            orderItem.setProductId(cartItem.getProductId());
            orderItem.setProductName(cartItem.getProductName());
            orderItem.setPrice(cartItem.getPrice());
            orderItem.setQuantity(cartItem.getQuantity());
            orderItems.add(orderItem);
        }
        order.setItems(orderItems);

        // ✅ Handle payment method logic
        String paymentMethod = order.getModeOfPayment();

        if ("Wallet".equalsIgnoreCase(paymentMethod)) {
            Ewallet wallet = walletClient.getWalletByProfileId(order.getProfileId());
            System.out.println(wallet);

            Double remainingBalance = wallet.getCurrentBal() - order.getAmmountPaid();
            if (remainingBalance >= 0) {
                order.setOrderStatus("CONFIRMED");

                // ✅ Update wallet
                walletClient.updateWallet(
                    order.getProfileId(),
                    order.getAmmountPaid(),
                    "Order placed for amount: " + order.getAmmountPaid(),
                    "Debit"
                );
            } else {
                throw new RuntimeException("Payment failed, insufficient balance.");
            }

        } else if ("Razorpay".equalsIgnoreCase(paymentMethod)) {
            order.setOrderStatus("Pending"); // Will be updated after Razorpay callback
        } else if ("CashOnDelivery".equalsIgnoreCase(paymentMethod)) {
            order.setOrderStatus("CONFIRMED");
        } else {
            throw new RuntimeException("Unsupported payment method: " + paymentMethod);
        }

        System.out.println(order.getAddress());
        System.out.println(order);
        return orderRepository.save(order);
    }




    @Override
    public List<Orders> getAllOrders() {
        logger.info("Fetching all orders");
        return orderRepository.findAll();
    }

    @Override
    public String changeStatus(String status, int orderId) {
        logger.info("Changing status of order ID: {} to {}", orderId, status);
        Optional<Orders> orderOpt = orderRepository.findById(orderId);
        if (orderOpt.isPresent()) {
            Orders order = orderOpt.get();
            order.setOrderStatus(status);
            orderRepository.save(order);
            if(order.getModeOfPayment().equalsIgnoreCase("wallet"))
            {
            	Ewallet wal = walletClient.getWalletByProfileId(order.getProfileId());
            	walletClient.updateWallet(order.getProfileId(), order.getAmmountPaid(), "Refund", "Credit");
            }
            logger.info("Order status updated successfully");
            return "Order status updated to: " + status;
        }
        logger.warn("Order not found with ID: {}", orderId);
        return "Order not found!";
    }

    @Override
    public String deleteOrder(int orderId) {
        logger.info("Deleting order with ID: {}", orderId);
        if (orderRepository.existsById(orderId)) {
            orderRepository.deleteById(orderId);
            logger.info("Order deleted successfully");
            return "Deleted successfully";
        }
        logger.warn("Order not found with ID: {}", orderId);
        return "Order not found!";
    }
    @Override
    public List<Orders> getOrderByProfileId(Integer profileId) {
        logger.info("Fetching orders for profileId: {}", profileId);
        List<Orders> ord = orderRepository.findByProfileId(profileId);

        if (ord != null) {
            ord.sort(Comparator.comparing(Orders::getOrderId).reversed()); // Ascending order
            // ord.sort(Comparator.comparing(Orders::getOrderId).reversed()); // For descending order
        }

        return ord;
    }

//    @Override
//    public List<Orders> getOrderByProfileId(Integer profileId) {
//        logger.info("Fetching orders for profileId: {}", profileId);
//        List<Orders> ord = orderRepository.findByProfileId(profileId);
//        List<Orders> ord1 = ord.stream().sorted((e1,e2)-> e1.getOrderId().)
//        return ord1;
//       
//    }

    @Override
    public List<Address> storeAddress(Address address) {
        logger.info("Storing address: {}", address);
        addressRepository.save(address);
        return addressRepository.findAll();
    }

    @Override
    public List<Address> getAddressByProfileId(Integer profileId) {
        logger.info("Fetching addresses for profileId: {}", profileId);
        return addressRepository.findByProfileId(profileId);
    }

    @Override
    public List<Address> getAllAddresses() {
        logger.info("Fetching all addresses");
        return addressRepository.findAll();
    }

    @Override
    public Optional<Orders> getOrderById(int orderId) {
        logger.info("Fetching order with ID: {}", orderId);
        return orderRepository.findById(orderId);
    }

    @Override
    public void onlinePayment(Cart cart) {
        logger.info("Processing online payment for cart: {}", cart);
        List<Orders> customerOrders = orderRepository.findByProfileId(cart.getProfileId());
        if (!customerOrders.isEmpty()) {
            Orders order = customerOrders.get(customerOrders.size() - 1);
            order.setAmmountPaid(cart.getTotalPrice());
            order.setModeOfPayment("Online");
            order.setOrderStatus("Paid");
            orderRepository.save(order);
            logger.info("Online payment processed successfully for order ID: {}", order.getOrderId());
        } else {
            logger.warn("No orders found for profileId: {}", cart.getProfileId());
        }
    }

    @Override
    public List<Orders> findLatestOrders() {
        logger.info("Fetching latest orders");
        return orderRepository.findLatestOrders();
    }
    
    public String createOrderPaymentLink(int profileId, double amount, int orderId) {
        String keyId = "rzp_test_ZCxFKPgSpv6kQ2";
        String keySecret = "GqXc5GjVPhPHjUYjdcaqHiTS";
        String callbackUrl = "http://localhost:9194/orders/payment-callback"; // Frontend route

        try {
            RazorpayClient razorpayClient = new RazorpayClient(keyId, keySecret);

            String referenceId = "ORDER_" + orderId + "_" + UUID.randomUUID().toString().substring(0, 10);

            JSONObject paymentLinkRequest = new JSONObject();
            paymentLinkRequest.put("amount", (int)(amount * 100));
            paymentLinkRequest.put("currency", "INR");
            paymentLinkRequest.put("accept_partial", false);
            paymentLinkRequest.put("expire_by", (System.currentTimeMillis() / 1000) + 3600);
            paymentLinkRequest.put("reference_id", referenceId);
            paymentLinkRequest.put("description", "Payment for Order ID: " + orderId);
            paymentLinkRequest.put("callback_url", callbackUrl);
            paymentLinkRequest.put("callback_method", "get");
//            paymentLinkRequest.put("redirect", true); // ✅ This is required

            PaymentLink paymentLink = razorpayClient.paymentLink.create(paymentLinkRequest);
            return paymentLink.get("short_url");

        } catch (RazorpayException e) {
            e.printStackTrace();
            return "Error creating payment link";
        }
    }



    @Override
    public void updateOrderStatus(int orderId, String status, String paymentId) {
        Optional<Orders> optionalOrder = orderRepository.findById(orderId);

        if (optionalOrder.isPresent()) {
            Orders order = optionalOrder.get();
            order.setOrderStatus(status);
            order.setPaymentId(paymentId);
            orderRepository.save(order);
        } else {
            throw new RuntimeException("Order not found with ID: " + orderId);
        }
    }


}
