package com.order.orderservice.orders.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.order.orderservice.orders.Orders;
@EnableJpaRepositories
public interface OrderRepository extends JpaRepository<Orders, Integer> {
	
	List<Orders> findByProfileId(Integer profileId);
	
	@Query("SELECT o FROM Orders o ORDER BY o.orderDate DESC")
    List<Orders> findLatestOrders();
	

}
