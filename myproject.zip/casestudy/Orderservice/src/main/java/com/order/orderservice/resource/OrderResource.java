package com.order.orderservice.resource;

import jakarta.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.order.orderservice.cart.Cart;
import com.order.orderservice.orders.Orders;
import com.order.orderservice.orders.service.OrderService;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/orders")
public class OrderResource {

    @Autowired
    private OrderService orderService;

    // ✅ Fetch all orders
    @GetMapping("/all")
    public List<Orders> getAllOrders() {
        return orderService.getAllOrders();
    }

    // ✅ Place a new order
    @PostMapping("/place")
    public Orders placeOrder(@RequestBody Orders order) {
    	System.out.println(order);
        return orderService.placeOrder(order);
    }

    // ✅ Get order by ID
    @GetMapping("/{orderId}")
    public Optional<Orders> getOrderById(@PathVariable int orderId) {
        return orderService.getOrderById(orderId);
    }

    // ✅ Get orders by Customer ID
    @GetMapping("/customer/{profileId}")
    public List<Orders> getOrdersByProdileId(@PathVariable Integer profileId) {
        return orderService.getOrderByProfileId(profileId);
    }

    // ✅ Update order status
    @PutMapping("/{orderId}/status")
    public String changeOrderStatus(@PathVariable int orderId, @RequestParam String status) {
        return orderService.changeStatus(status, orderId);
    }

    // ✅ Delete an order
    @DeleteMapping("/{orderId}")
    public String deleteOrder(@PathVariable int orderId) {
        return orderService.deleteOrder(orderId);
    }

    // ✅ Process online payment
    @PostMapping("/payment")
    public void processPayment(@RequestBody Cart cart) {
        orderService.onlinePayment(cart);
    }

    // ✅ Get latest orders
    @GetMapping("/latest")
    public List<Orders> getLatestOrders() {
        return orderService.findLatestOrders();
    }
    @GetMapping("/create-payment-link")
    public ResponseEntity<String> createPaymentLink(
            @RequestParam int profileId,
            @RequestParam double amount,
            @RequestParam int orderId) {

        String paymentLink = orderService.createOrderPaymentLink(profileId, amount, orderId);
        return ResponseEntity.ok(paymentLink);
    }
    @GetMapping("/payment-callback")
    public void handlePaymentCallback(
            @RequestParam("razorpay_payment_link_reference_id") String referenceId,
            @RequestParam("razorpay_payment_id") String paymentId,
            HttpServletResponse response) throws IOException {

        if (referenceId == null || paymentId == null) {
            response.sendRedirect("http://localhost:3000/payment-failed");
            return;
        }

        try {
            String[] parts = referenceId.split("_");
            int orderId = Integer.parseInt(parts[1]);

            orderService.updateOrderStatus(orderId, "Paid", paymentId);

            // ✅ Redirect to homepage or thank-you page
            response.sendRedirect("http://localhost:3000/home");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("http://localhost:3000/payment-failed");
        }
    }



    
}