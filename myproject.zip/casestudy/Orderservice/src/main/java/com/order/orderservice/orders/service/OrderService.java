package com.order.orderservice.orders.service;

import java.util.List;
import java.util.Optional;

import com.order.orderservice.cart.Cart;
import com.order.orderservice.orders.Orders;
import com.order.orderservice.orders.address.Address;

public interface OrderService {
	
	List<Orders> getAllOrders();
	
	Orders placeOrder(Orders order);
	
	String changeStatus(String orderStatus,int orderId);
	
	String deleteOrder(int orderId);
	
	List<Orders> getOrderByProfileId(Integer profileId);
	
	List<Address> storeAddress(Address address);
	
	List<Address> getAddressByProfileId(Integer profileId);
	
	List<Address> getAllAddresses();
	
	Optional<Orders> getOrderById(int orderId);
	
	void onlinePayment(Cart cart);

	List<Orders> findLatestOrders();

	String createOrderPaymentLink(int profileId, double amount, int orderId);

	void updateOrderStatus(int orderId, String status, String paymentId);
	
	

}
