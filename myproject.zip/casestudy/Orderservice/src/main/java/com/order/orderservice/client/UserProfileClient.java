package com.order.orderservice.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.order.orderservice.orders.address.Address;

@FeignClient(name = "PROFILESERVICE") 
public interface UserProfileClient {
	@GetMapping("/profile/address/{profileId}")
    public List<Address> getAddressByProfileId(@PathVariable int profileId);
}