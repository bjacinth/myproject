package com.order.orderservice.orders.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.time.LocalDate;
import java.util.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.order.orderservice.client.CartClient;
import com.order.orderservice.client.WalletClient;
import com.order.orderservice.orders.Orders;
import com.order.orderservice.orders.address.Address;
import com.order.orderservice.orders.repository.AddressRepository;
import com.order.orderservice.orders.repository.OrderRepository;
import com.order.orderservice.orders.service.OrderServiceImpl;
import com.order.orderservice.wallet.Ewallet;

class OrderServiceImplTest {

    @InjectMocks
    private OrderServiceImpl orderService;

    @Mock
    private OrderRepository orderRepository;

    @Mock
    private AddressRepository addressRepository;

    @Mock
    private CartClient cartClient;

    @Mock
    private WalletClient walletClient;

    private Orders mockOrder;
    private Ewallet mockWallet;
    private Address mockAddress;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        mockOrder = new Orders();
        mockOrder.setOrderId(1);
        mockOrder.setProfileId(1001);
        mockOrder.setAmmountPaid(200.0);
        mockOrder.setOrderStatus("PENDING");

        mockWallet = new Ewallet();
        mockWallet.setWalletId(5001);
        mockWallet.setProfileId(1001);
        mockWallet.setCurrentBal(500.0);

        mockAddress = new Address();
        mockAddress.setProfileId(1001);
    }

    @Test
    void testPlaceOrder_Success() {
        when(walletClient.getWalletByProfileId(1001)).thenReturn(mockWallet);
//        when(walletClient.updateWallet(eq(1001), eq(200.0), eq("Debited"), eq("Online"))).thenReturn(1.0);
        when(orderRepository.save(any(Orders.class))).thenReturn(mockOrder);

        Orders placedOrder = orderService.placeOrder(mockOrder);

        assertNotNull(placedOrder);
        assertEquals("CONFIRMED", placedOrder.getOrderStatus());
        verify(walletClient, times(1)).updateWallet(eq(1001), eq(200.0), eq("Debited"), eq("Online"));
        verify(orderRepository, times(1)).save(mockOrder);
    }

    @Test
    void testPlaceOrder_InsufficientBalance() {
        mockWallet.setCurrentBal(100.0);
        when(walletClient.getWalletByProfileId(1001)).thenReturn(mockWallet);

        RuntimeException exception = assertThrows(RuntimeException.class, () -> orderService.placeOrder(mockOrder));
        assertEquals("Payment failed, insufficient balance.", exception.getMessage());

        verify(orderRepository, never()).save(any());
    }

    @Test
    void testGetAllOrders() {
        List<Orders> ordersList = Arrays.asList(mockOrder);
        when(orderRepository.findAll()).thenReturn(ordersList);

        List<Orders> result = orderService.getAllOrders();

        assertEquals(1, result.size());
        verify(orderRepository, times(1)).findAll();
    }

    @Test
    void testChangeStatus_Success() {
        when(orderRepository.findById(1)).thenReturn(Optional.of(mockOrder));
        when(orderRepository.save(any(Orders.class))).thenReturn(mockOrder);

        String result = orderService.changeStatus("SHIPPED", 1);

        assertEquals("Order status updated to: SHIPPED", result);
        verify(orderRepository, times(1)).save(mockOrder);
    }

    @Test
    void testChangeStatus_OrderNotFound() {
        when(orderRepository.findById(2)).thenReturn(Optional.empty());

        String result = orderService.changeStatus("SHIPPED", 2);

        assertEquals("Order not found!", result);
        verify(orderRepository, never()).save(any());
    }

    @Test
    void testDeleteOrder_Success() {
        when(orderRepository.existsById(1)).thenReturn(true);
        doNothing().when(orderRepository).deleteById(1);

        String result = orderService.deleteOrder(1);

        assertEquals("Deleted successfully", result);
        verify(orderRepository, times(1)).deleteById(1);
    }

    @Test
    void testDeleteOrder_OrderNotFound() {
        when(orderRepository.existsById(2)).thenReturn(false);

        String result = orderService.deleteOrder(2);

        assertEquals("Order not found!", result);
        verify(orderRepository, never()).deleteById(2);
    }

    @Test
    void testGetOrderByProfileId() {
        List<Orders> ordersList = Arrays.asList(mockOrder);
        when(orderRepository.findByProfileId(1001)).thenReturn(ordersList);

        List<Orders> result = orderService.getOrderByProfileId(1001);

        assertEquals(1, result.size());
        verify(orderRepository, times(1)).findByProfileId(1001);
    }

    @Test
    void testStoreAddress() {
        when(addressRepository.save(any(Address.class))).thenReturn(mockAddress);
        when(addressRepository.findAll()).thenReturn(Collections.singletonList(mockAddress));

        List<Address> addresses = orderService.storeAddress(mockAddress);

        assertEquals(1, addresses.size());
        verify(addressRepository, times(1)).save(mockAddress);
        verify(addressRepository, times(1)).findAll();
    }

    @Test
    void testGetAddressByProfileId() {
        List<Address> addressList = Arrays.asList(mockAddress);
        when(addressRepository.findByProfileId(1001)).thenReturn(addressList);

        List<Address> result = orderService.getAddressByProfileId(1001);

        assertEquals(1, result.size());
        verify(addressRepository, times(1)).findByProfileId(1001);
    }

    @Test
    void testGetAllAddresses() {
        List<Address> addressList = Arrays.asList(mockAddress);
        when(addressRepository.findAll()).thenReturn(addressList);

        List<Address> result = orderService.getAllAddresses();

        assertEquals(1, result.size());
        verify(addressRepository, times(1)).findAll();
    }

    @Test
    void testGetOrderById_Success() {
        when(orderRepository.findById(1)).thenReturn(Optional.of(mockOrder));

        Optional<Orders> orderOpt = orderService.getOrderById(1);

        assertTrue(orderOpt.isPresent());
        assertEquals(1, orderOpt.get().getOrderId());
        verify(orderRepository, times(1)).findById(1);
    }

    @Test
    void testGetOrderById_NotFound() {
        when(orderRepository.findById(2)).thenReturn(Optional.empty());

        Optional<Orders> orderOpt = orderService.getOrderById(2);

        assertFalse(orderOpt.isPresent());
        verify(orderRepository, times(1)).findById(2);
    }

    @Test
    void testFindLatestOrders() {
        List<Orders> ordersList = Arrays.asList(mockOrder);
        when(orderRepository.findLatestOrders()).thenReturn(ordersList);

        List<Orders> result = orderService.findLatestOrders();

        assertEquals(1, result.size());
        verify(orderRepository, times(1)).findLatestOrders();
    }
}
