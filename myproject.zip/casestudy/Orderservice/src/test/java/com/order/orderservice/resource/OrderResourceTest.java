package com.order.orderservice.resource;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.order.orderservice.orders.Orders;
import com.order.orderservice.orders.service.OrderService;
import com.order.orderservice.resource.OrderResource;

import java.util.Collections;
import java.util.Optional;

public class OrderResourceTest {

    private MockMvc mockMvc;

    @Mock
    private OrderService orderService;

    @InjectMocks
    private OrderResource orderResource;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(orderResource).build();
    }

    @Test
    void testGetAllOrders() throws Exception {
        when(orderService.getAllOrders()).thenReturn(Collections.emptyList());
        
        mockMvc.perform(get("/orders/all"))
                .andExpect(status().isOk());
    }

    @Test
    void testPlaceOrder() throws Exception {
        Orders order = new Orders();
        order.setOrderId(1);
        when(orderService.placeOrder(any(Orders.class))).thenReturn(order);
        
        mockMvc.perform(post("/orders/place")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"profileId\":101, \"ammountPaid\":200.0}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.orderId").value(1));
    }

    @Test
    void testGetOrderById() throws Exception {
        Orders order = new Orders();
        order.setOrderId(1);
        when(orderService.getOrderById(1)).thenReturn(Optional.of(order));
        
        mockMvc.perform(get("/orders/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.orderId").value(1));
    }

    @Test
    void testGetOrderById_NotFound() throws Exception {
        when(orderService.getOrderById(1)).thenReturn(Optional.empty());
        
        mockMvc.perform(get("/orders/1"))
                .andExpect(status().isOk());
    }

    @Test
    void testChangeOrderStatus() throws Exception {
        when(orderService.changeStatus("Shipped", 1)).thenReturn("Order status updated to: Shipped");
        
        mockMvc.perform(put("/orders/1/status")
                        .param("status", "Shipped"))
                .andExpect(status().isOk())
                .andExpect(content().string("Order status updated to: Shipped"));
    }

    @Test
    void testDeleteOrder() throws Exception {
        when(orderService.deleteOrder(1)).thenReturn("Deleted successfully");
        
        mockMvc.perform(delete("/orders/1"))
                .andExpect(status().isOk())
                .andExpect(content().string("Deleted successfully"));
    }
}