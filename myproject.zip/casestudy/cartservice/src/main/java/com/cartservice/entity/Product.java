package com.cartservice.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
@Entity
public class Product {
	@Id
	//@NotNull(message = "productId should not be null")
	private int productId;
//	@NotNull(message = "productType should not be blank")
	private String productType;
//	@NotNull(message = "productName ahould not be blank")
	private String productName;
//
//	@NotNull(message = "price must be positive and not null")
	private Double price;
//	
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public Product(int productId, String productType, String productName, Double price) {
		super();
		this.productId = productId;
		this.productType = productType;
		this.productName = productName;
		this.price = price;
	}
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}

}
