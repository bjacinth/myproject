package com.cartservice.service;

import java.util.List;

import com.cartservice.entity.Cart;
import com.cartservice.entity.Items;

public interface CartService {
	List<Cart> getcarts();
    Cart getCartById(int cartId);
    Cart getCartByProfileId(int profileId);
    Cart updateCartItem(int cartId, int itemId, int quantity);
    double cartTotalByCartId(List<Items> items);
    double cartTotalByProfileId(int profileId);
    Cart addItemToCart(int profileId, int productId, int quantity);
    Cart removeItemFromCart(int cartId, int itemId);
	Cart createCart(int cartId);
	void deletecart(int profileId);
}