package com.cartservice.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cartservice.client.ProductServiceClient;
import com.cartservice.entity.Cart;
import com.cartservice.entity.Items;
import com.cartservice.entity.Product;
import com.cartservice.exception.CartNotFoundException;
import com.cartservice.exception.InvalidQuantityException;
import com.cartservice.exception.ProductNotFoundException;
import com.cartservice.repository.CartRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class CartServiceImpl implements CartService {
    private static final Logger logger = LoggerFactory.getLogger(CartServiceImpl.class);

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private ProductServiceClient productServiceClient;
    
    @Override
    public Cart createCart(int cartId) {
        logger.info("Creating cart with ID: {}", cartId);
        
        System.out.println("hi");
        Optional<Cart> cart = cartRepository.findById(cartId);
        
//        logger.error("Cart with ID {} already exists.", cartId);
        if(cart.isEmpty()) {
        	cart = Optional.of(new Cart(0,0, 0.0, new ArrayList<>()));
        }
        System.out.println(cart);
        cartRepository.save(cart.get());
        
        return cart.get();
    }
    
    @Override
    public List<Cart> getcarts() {
        logger.info("Fetching all carts");
        return cartRepository.findAll();
    }

    @Override
    public Cart getCartById(int cartId) {
        logger.info("Fetching cart with ID: {}", cartId);
        return cartRepository.findByCartId(cartId);
    }
    
    @Override
    public Cart getCartByProfileId(int profileId) {
        logger.info("Fetching cart with profile ID: {}", profileId);
        return cartRepository.findByProfileId(profileId)
                .orElseThrow(() -> new CartNotFoundException("Cart not found with profileId " + profileId));
    }
    
    @Override
    public double cartTotalByCartId(List<Items> items) {
        logger.info("Calculating total price for cart items");
        return items.stream().mapToDouble(i -> i.getPrice() * i.getQuantity()).sum();
    }
    
    @Override
    public double cartTotalByProfileId(int profileId) {
        Cart cart = cartRepository.findByProfileId(profileId)
            .orElseThrow(() -> new CartNotFoundException("Cart not found with profileId " + profileId));

        return cart.getItems().stream()
            .mapToDouble(item -> item.getPrice() * item.getQuantity())
            .sum();
    }

    @Override
    public Cart updateCartItem(int cartId, int itemId, int quantity) {
        logger.info("Updating item with ID: {} in cart ID: {} with quantity: {}", itemId, cartId, quantity);
        
        Cart cart = getCartById(cartId);
        if (cart != null) {
            for (Items item : cart.getItems()) {
                if (item.getProductId() == itemId) {
                    item.setQuantity(quantity);
                    break;
                }
            }

            // Recalculate total price
            double newTotal = 0.0;
            for (Items item : cart.getItems()) {
                newTotal += item.getPrice() * item.getQuantity();
            }
            cart.setTotalPrice(newTotal);

            cartRepository.save(cart);
        }

        return cart;
    }

    @Override
    public Cart addItemToCart(int profileId, int productId, int quantity) {
        logger.info("Adding item with ID: {} to cart of profile ID: {} with quantity: {}", productId, profileId, quantity);
        
        if (quantity <= 0) {
            logger.error("Invalid quantity: {}", quantity);
            throw new InvalidQuantityException("Quantity must be greater than zero.");
        }

        Cart cart = cartRepository.findByProfileId(profileId)
                                  .orElseGet(() -> {
                                      Cart newCart = new Cart();
                                      newCart.setProfileId(profileId);
                                      newCart.setTotalPrice(0.0);
                                      newCart.setItems(new ArrayList<>());
                                      return newCart;
                                  });

        Product product = productServiceClient.getProductById(productId);
        if (product == null) {
            logger.error("Product with ID {} not found", productId);
            throw new ProductNotFoundException("Product not found with ID: " + productId);
        }

        Items newItem = new Items(product.getProductId(), product.getProductName(), product.getPrice(), quantity);
        newItem.setCart(cart); // ✅ This line is essential
        cart.getItems().add(newItem);

        
        cart.setTotalPrice(cartTotalByCartId(cart.getItems()));
        logger.info("Updated cart: {}", cart);

        return cartRepository.save(cart);
    }


    @Override
    @Transactional
    public Cart removeItemFromCart(int profileId, int productId) {
    	
        logger.info("Removing item with ID: {} from profile ID: {}", productId, profileId);
        Cart cart = getCartByProfileId(profileId);
        
        if (cart == null) {
            logger.error("Cart with profile ID {} not found", profileId);
            throw new CartNotFoundException("Cart with profile ID " + profileId + " not found.");
        }

        boolean itemRemoved = cart.getItems().removeIf(item -> item.getProductId() == productId);
        
        if (!itemRemoved) {
            logger.error("Item with ID {} not found in cart of profileID {}", productId, profileId);
            throw new RuntimeException("Item with ID " + productId + " not found in the cart.");
        }

        cart.setTotalPrice(cartTotalByCartId(cart.getItems()));
        return cartRepository.save(cart);
    }
    @Override
    public void deletecart(int profileId) {
    	
    	Cart cart = getCartByProfileId(profileId);
    	cartRepository.delete(cart);
    }
    
}
