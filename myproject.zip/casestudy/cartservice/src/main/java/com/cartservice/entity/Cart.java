package com.cartservice.entity;

import jakarta.persistence.*;
import java.util.List;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
public class Cart {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int cartId;
    private int profileId;
    private Double totalPrice;
    @OneToMany(mappedBy = "cart", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    private List<Items> items;

    
    public Cart() {
        super();
    }

    public Cart(int cartId,int profileId, Double totalPrice, List<Items> items) {
        this.cartId = cartId;
        this.profileId = profileId;
        this.totalPrice = totalPrice;
        this.items = items;
    }
    

    public int getCartId() {
        return cartId;
    }

    public void setCartId(int cartId) {
        this.cartId = cartId;
    }
    
    public int getProfileId() {
    	return profileId;
    }
    
    public void setProfileId(int profileId) {
    	this.profileId = profileId;
    }

    public Double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(Double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public List<Items> getItems() {
        return items;
    }

    public void setItems(List<Items> items) {
        this.items = items;
    }

	@Override
	public int hashCode() {
		return Objects.hash(cartId, items, profileId, totalPrice);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Cart other = (Cart) obj;
		return cartId == other.cartId && Objects.equals(items, other.items) && profileId == other.profileId
				&& Objects.equals(totalPrice, other.totalPrice);
	}

    
}