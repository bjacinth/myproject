package com.cartservice.client;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.cartservice.entity.Product;

import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name = "PRODUCTSERVICE")
public interface ProductServiceClient {
    @GetMapping("/product/id/{productId}")
    Product getProductById(@PathVariable("productId") int productId);
}
