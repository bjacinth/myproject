package com.cartservice.cartresource;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cartservice.entity.Cart;
import com.cartservice.service.CartService;
@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/cart")
public class CartResource {
    @Autowired
    private CartService cartService;
    
    @PostMapping("/create/{cartId}")
    public ResponseEntity<Cart> createCart(@PathVariable int cartId) {
        Cart newCart = cartService.createCart(cartId);
        return ResponseEntity.ok(newCart);
    }
    
    @GetMapping("/all")
    public List<Cart> getcarts() {
        return cartService.getcarts();
    }

    @GetMapping("/cart/{cartId}")
    public Cart getCartById(@PathVariable int cartId) {
        return cartService.getCartById(cartId);
    }
    @GetMapping("/profile/{profileId}")
    public Cart getCartByProfileId(@PathVariable int profileId) {
        return cartService.getCartByProfileId(profileId);
    }

    @GetMapping("/total/cartId/{cartId}")
    public double getCartTotalByCartId(@PathVariable int cartId) {
        return cartService.getCartById(cartId).getTotalPrice();
    }
    
    @GetMapping("/total/profileId/{profileId}")
    public double getCartTotalByProfileId(@PathVariable int profileId) {
        return cartService.cartTotalByProfileId(profileId);
    }

    @PutMapping("/update/{cartId}/{productId}/{quantity}")
    public Cart updateCartItem(@PathVariable int cartId, @PathVariable int productId, @PathVariable int quantity) {
        return cartService.updateCartItem(cartId, productId, quantity);
    }
   
    @PostMapping("/add/{profileId}/{productId}/{quantity}")
    public Cart addItemToCart(@PathVariable int profileId, @PathVariable int productId, @PathVariable int quantity) {
        return cartService.addItemToCart(profileId, productId, quantity);
    }

    @DeleteMapping("/remove/{cartId}/{productId}")
    public Cart removeItemFromCart(@PathVariable int cartId, @PathVariable int productId) {
        return cartService.removeItemFromCart(cartId, productId);
    }
    @DeleteMapping("delete/{profileId}")
    public void deleteCart(@PathVariable int profileId) {
    	cartService.deletecart(profileId);
    }
}
