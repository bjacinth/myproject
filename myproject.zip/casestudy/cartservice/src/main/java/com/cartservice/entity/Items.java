package com.cartservice.entity;

import jakarta.persistence.*;


import com.fasterxml.jackson.annotation.JsonBackReference;
@Entity
public class Items {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int itemId;
    private int productId;
    private String productName;
    private Double price;
    private int quantity;
 // Items.java
 @ManyToOne
 @JoinColumn(name = "cart_id")
 @JsonBackReference
 private Cart cart;


    public Items() {
        super();
    }
	@Override
	public String toString() {
		return "Items [itemId=" + itemId + ", productId=" + productId + ", productName=" + productName + ", price="
				+ price + ", quantity=" + quantity + ", cart=" + cart + "]";
	}
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public Cart getCart() {
		return cart;
	}
	public void setCart(Cart cart) {
		this.cart = cart;
	}
	public Items(int itemId, int productId, String productName, Double price, int quantity, Cart cart) {
		super();
		this.itemId = itemId;
		this.productId = productId;
		this.productName = productName;
		this.price = price;
		this.quantity = quantity;
		this.cart = cart;
	}
	public Items(int productId, String productName, Double price, int quantity) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.price = price;
		this.quantity = quantity;
	}


}