package com.cartservice.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cartservice.client.ProductServiceClient;
import com.cartservice.entity.Cart;
import com.cartservice.entity.Items;
import com.cartservice.entity.Product;
import com.cartservice.exception.CartNotFoundException;
import com.cartservice.exception.InvalidQuantityException;
import com.cartservice.exception.ProductNotFoundException;
import com.cartservice.repository.CartRepository;
import com.cartservice.service.CartServiceImpl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CartServiceImplTest {

    @Mock
    private CartRepository cartRepository;

    @Mock
    private ProductServiceClient productServiceClient;

    @InjectMocks
    private CartServiceImpl cartService;

    private Cart cart;
    private Items item;
    private Product product;

    @BeforeEach
    void setUp() {
        item = new Items(1, "Laptop", 1000.0, 1);
        cart = new Cart(1, 101, 1000.0, new ArrayList<>(List.of(item)));
        product = new Product(1, "Electronics", "Laptop", 1000.0);
    }

    @Test
    void testCreateCart() {
        when(cartRepository.existsById(1)).thenReturn(false);
        when(cartRepository.save(any(Cart.class))).thenReturn(cart);

        Cart createdCart = cartService.createCart(1);
        assertNotNull(createdCart);
        assertEquals(1, createdCart.getCartId());
    }

    @Test
    void testGetCartById() {
        when(cartRepository.findByCartId(1)).thenReturn(cart);

        Cart foundCart = cartService.getCartById(1);
        assertNotNull(foundCart);
        assertEquals(1, foundCart.getCartId());
    }

    @Test
    void testGetCartByProfileId() {
        when(cartRepository.findByProfileId(101)).thenReturn(null, null);

        Cart foundCart = cartService.getCartByProfileId(101);
        assertNotNull(foundCart);
        assertEquals(101, foundCart.getProfileId());
    }

    @Test
    void testCartTotalByCartId() {
        double total = cartService.cartTotalByCartId(cart.getItems());
        assertEquals(1000.0, total);
    }

    @Test
    void testCartTotalByProfileId() {
        // Create a test cart
        Cart cart = new Cart();
        cart.setProfileId(101);

        Items item1 = new Items(0, null, 100.0, 2); 
        Items item2 = new Items(0, null, 50.0, 3); 

        cart.setItems(List.of(item1, item2)); 

        when(cartRepository.findByProfileId(101)).thenReturn(Optional.of(cart));

        double total = cartService.cartTotalByProfileId(101); 
        assertEquals(350.0, total);
    }


    @Test
    void testUpdateCartItem() {
        when(cartRepository.findByCartId(1)).thenReturn(cart);
        when(cartRepository.save(any(Cart.class))).thenReturn(cart);

        Cart updatedCart = cartService.updateCartItem(1, 1, 2);
        assertEquals(2, updatedCart.getItems().get(0).getQuantity());
    }

    @Test
    void testAddItemToCart() {
        when(cartRepository.findByProfileId(101)).thenReturn(Optional.of(cart)); 
        when(productServiceClient.getProductById(1)).thenReturn(product);
        when(cartRepository.save(any(Cart.class))).thenReturn(cart);

        Cart updatedCart = cartService.addItemToCart(101, 1, 2);
        assertEquals(2, updatedCart.getItems().get(1).getQuantity());
    }


    @Test
    void testRemoveItemFromCart() {
        when(cartRepository.findByCartId(1)).thenReturn(cart);
        when(cartRepository.save(any(Cart.class))).thenReturn(cart);

        Cart updatedCart = cartService.removeItemFromCart(1, 1);
        assertTrue(updatedCart.getItems().isEmpty());
    }

    @Test
    void testRemoveItemFromCart_NotFound() {
        when(cartRepository.findByCartId(1)).thenReturn(cart);

        Exception exception = assertThrows(RuntimeException.class, () -> cartService.removeItemFromCart(1, 2));
        assertEquals("Item with ID 2 not found in the cart.", exception.getMessage());
    }
}
