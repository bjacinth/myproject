package com.cartservice.cartresource;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import com.cartservice.cartresource.CartResource;
import com.cartservice.entity.Cart;
import com.cartservice.service.CartService;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CartResourceTest {

    @Mock
    private CartService cartService;

    @InjectMocks
    private CartResource cartResource;

    private Cart cart;

    @BeforeEach
    void setUp() {
        cart = new Cart(1, 101, 1000.0, List.of());
    }

    @Test
    void testCreateCart() {
        when(cartService.createCart(1)).thenReturn(cart);

        ResponseEntity<Cart> response = cartResource.createCart(1);
        assertNotNull(response.getBody());
        assertEquals(1, response.getBody().getCartId());
    }

    @Test
    void testGetCarts() {
        when(cartService.getcarts()).thenReturn(List.of(cart));

        List<Cart> carts = cartResource.getcarts();
        assertEquals(1, carts.size());
    }

    @Test
    void testGetCartById() {
        when(cartService.getCartById(1)).thenReturn(cart);

        Cart foundCart = cartResource.getCartById(1);
        assertEquals(1, foundCart.getCartId());
    }

    @Test
    void testUpdateCartItem() {
        when(cartService.updateCartItem(1, 1, 2)).thenReturn(cart);

        Cart updatedCart = cartResource.updateCartItem(1, 1, 2);
        assertNotNull(updatedCart);
    }

    @Test
    void testRemoveItemFromCart() {
        when(cartService.removeItemFromCart(1, 1)).thenReturn(cart);

        Cart updatedCart = cartResource.removeItemFromCart(1, 1);
        assertNotNull(updatedCart);
    }
}
