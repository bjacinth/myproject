package com.eshoppingZone.ewallet.pojo;

import java.util.List;


import jakarta.persistence.CascadeType;
import jakarta.persistence.CollectionTable;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
@Entity
public class Ewallet {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer walletId;
	private Double currentBal;
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "walletId")
	private List<Statement> statements;
	private int profileId;
	
	public Ewallet() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Ewallet(Double currentBal, List<Statement> statements, int profileId) {
		super();
		this.currentBal = currentBal;
		this.statements = statements;
		this.profileId = profileId;
	}

	public Ewallet(Integer walletId, Double currentBal, List<Statement> statements, int profileId) {
		super();
		this.walletId = walletId;
		this.currentBal = currentBal;
		this.statements = statements;
		this.profileId = profileId;
	}

	public Integer getWalletId() {
		return walletId;
	}

	public void setWalletId(Integer walletId) {
		this.walletId = walletId;
	}

	public Double getCurrentBal() {
		return currentBal;
	}

	public void setCurrentBal(Double currentBal) {
		this.currentBal = currentBal;
	}

	public List<Statement> getStatements() {
		return statements;
	}

	public void setStatements(List<Statement> statements) {
		this.statements = statements;
	}

	public int getProfileId() {
		return profileId;
	}

	public void setProfileId(int profileId) {
		this.profileId = profileId;
	}

	@Override
	public String toString() {
		return "Ewallet [walletId=" + walletId + ", currentBal=" + currentBal + ", statements=" + statements
				+ ", profileId=" + profileId + "]";
	}
	
	

}
