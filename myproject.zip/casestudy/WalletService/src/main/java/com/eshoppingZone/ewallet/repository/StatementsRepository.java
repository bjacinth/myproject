package com.eshoppingZone.ewallet.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eshoppingZone.ewallet.pojo.Statement;

public interface StatementsRepository extends JpaRepository<Statement, Integer> {

}
