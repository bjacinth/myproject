package com.eshoppingZone.ewallet.resource;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.eshoppingZone.ewallet.pojo.Ewallet;
import com.eshoppingZone.ewallet.pojo.Statement;
import com.eshoppingZone.ewallet.pojo.WalletAdder;
import com.eshoppingZone.ewallet.service.EwalletService;

@RestController
@RequestMapping("/wallet")
@CrossOrigin(origins = "http://localhost:3000")

class WallerResource {
    @Autowired
    private EwalletService ewalletService;
    
    @GetMapping("/all")
    public List<Ewallet> getWallets(){
    	return ewalletService.getWallets();
    }
    @PostMapping("/addwallet")
    public Ewallet addWallet(@RequestBody Ewallet wallet) {
    	return ewalletService.addWallet(wallet);
    }
    @PostMapping("/addmoney/{walletId}/{amount}/{transactionRemarks}")
    public void addMoney(@PathVariable Integer walletId,@PathVariable Double amount,@PathVariable String transactionRemarks) {
    	ewalletService.addMoney(walletId, amount, transactionRemarks);
    }
    @PutMapping("/update/{profileId}/{amount}/{transactionRemarks}/{transactionType}")
    public void updateWallet(@PathVariable Integer profileId,@PathVariable Double amount,@PathVariable String transactionRemarks,@PathVariable String transactionType) {
    	ewalletService.updateWallet(profileId, amount, transactionRemarks, transactionType);
    }
    @PostMapping("/addmoney")
    public String addMoney(@RequestBody WalletAdder walletAdder) {
    	return ewalletService.addMoney(walletAdder);
    }
    @DeleteMapping("/delete/id/{walletId}")
    public void deleteById(@PathVariable Integer walletId) {
    	ewalletService.deleteById(walletId);
    }
    @GetMapping("/walletId/{walletId}")
    Ewallet getById(@PathVariable Integer walletId) {
    	return ewalletService.getById(walletId);
    }
    @GetMapping("/statments/{walletId}")
    List<Statement> getStatementsById(@PathVariable Integer walletId){
    	return ewalletService.getStatementsById(walletId);
    }
    @GetMapping("/statements")
    List<Statement> getStatements(){
    	return ewalletService.getStatements();
    }
    @GetMapping("/profileId/{profileId}")
    public Ewallet getWalletByProfileId(@PathVariable Integer profileId) {
    	return ewalletService.getWalletByProfileId(profileId);
    }
    
    
    
//    razorpay method
    @PostMapping("/create-payment-link")
    public ResponseEntity<String> createPaymentLink(
            @RequestParam int profileId,
            @RequestParam double amount
            ) {

        String paymentLink = ewalletService.createPaymentLink(profileId , amount);
        return ResponseEntity.ok(paymentLink);
    }
    @GetMapping("/callback")
    public String paymentCallback(@RequestParam String razorpay_payment_id,
                                  @RequestParam String razorpay_payment_link_id,
                                  @RequestParam String razorpay_payment_link_status,
                                  @RequestParam String razorpay_payment_link_reference_id) {

        if (!"paid".equals(razorpay_payment_link_status)) {
            return "Payment failed.";
        }

        // 🔹 Extract userId and amount from reference_id
        String[] referenceParts = razorpay_payment_link_reference_id.split("_");
        if (referenceParts.length < 2) {
            return "Invalid reference ID format.";
        }

        int profileId = Integer.parseInt(referenceParts[0]);
        double amount = Double.parseDouble(referenceParts[1]);

        // 🔹 Add money to wallet
        WalletAdder walletAdder = new WalletAdder(profileId, amount, "Payment via Razorpay");
        ewalletService.addMoney(walletAdder);

        return "Payment successful! Wallet updated.";
    }
    @PostMapping("/createwallet/{profileId}")
    public Ewallet createwallet(@PathVariable int profileId) {
    	return ewalletService.createwallet(profileId);
    }
    
    


    
    
    
////    
////    public Integer getWalletId(Integer walletId) {
////    	return ewalletService.getWalletId(walletId);
////    }
////    
//    @GetMapping
//    public List<Ewallet> getWallets() {
//        return ewalletService.getWallets();
//    }
//    
//    @PostMapping("/add")
//    public ResponseEntity<Ewallet> createWallet(@RequestBody Ewallet ewallet) {
//        return ResponseEntity.ok(ewalletService.createWallet(ewallet));
//    }
//    
//    @PostMapping("/addMoney/{walletId}/{amount}")
//    public ResponseEntity<String> addMoney(@PathVariable Integer walletId, @PathVariable Double amount) {
//        ewalletService.addMoney(walletId, amount);
//        return ResponseEntity.ok("Money added successfully");
//    }
//    
////    @PostMapping("/payMoney/{walletId}/{amount}")
////    public ResponseEntity<String> payMoney(@PathVariable Integer walletId, @PathVariable Double amount) {
////        ewalletService.payMoney(walletId, amount);
////        return ResponseEntity.ok("Payment successful");
////    }
//    
//    @GetMapping("/statements/{walletId}")
//    public List<Statement> getStatementsByWalletId(@PathVariable Integer walletId) {
//        return ewalletService.getStatementsByWalletId(walletId);
//    }
//
//    @GetMapping("/statements")
//    public List<Statement> getStatements() {
//        return ewalletService.getStatements();
//    }
//    @PostMapping("/wallet/deduct/{walletId}/{amount}")
//    public ResponseEntity<Double> deductBalance(@PathVariable Integer walletId, @PathVariable double amount) {
//        double remainingBalance = ewalletService.deduct(walletId, amount);
//        return ResponseEntity.ok(remainingBalance);
//    }
//    
//    
//    @DeleteMapping("/{walletId}")
//    public ResponseEntity<String> deleteWallet(@PathVariable Integer walletId) {
//        ewalletService.deleteById(walletId);
//        return ResponseEntity.ok("Wallet deleted successfully");
//    }
}



