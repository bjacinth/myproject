package com.eshoppingZone.ewallet.service;

import java.util.List;

import com.eshoppingZone.ewallet.exception.WalletNotFoundException;
import com.eshoppingZone.ewallet.pojo.Ewallet;
import com.eshoppingZone.ewallet.pojo.Statement;
import com.eshoppingZone.ewallet.pojo.WalletAdder;

public interface EwalletService {
	List<Ewallet> getWallets();
	
    Ewallet addWallet(Ewallet wallet);
    void addMoney(Integer walletId, Double amount,String transactionRemarks)throws WalletNotFoundException;
    void updateWallet(Integer walletId, Double amount, String transactionRemarks , String transactionType) throws WalletNotFoundException;
    Ewallet getById(Integer walletId) throws WalletNotFoundException;
    List<Statement> getStatementsById(Integer walletId) throws WalletNotFoundException;
    List<Statement> getStatements();
    void deleteById(Integer walletId) throws WalletNotFoundException;
    Ewallet getWalletByProfileId(Integer profileId);
    String addMoney(WalletAdder walletAdder);

	Ewallet getByProfileId(Integer profileId);
	String createPaymentLink(int userId, double amount);

	String createOrderPaymentLink(int profileId, double amount, int orderId);

	Ewallet createwallet(int profileId);



}
