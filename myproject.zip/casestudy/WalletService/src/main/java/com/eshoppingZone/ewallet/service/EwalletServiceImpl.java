package com.eshoppingZone.ewallet.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.eshoppingZone.ewallet.exception.WalletNotFoundException;
import com.eshoppingZone.ewallet.pojo.Ewallet;
import com.eshoppingZone.ewallet.pojo.Statement;
import com.eshoppingZone.ewallet.pojo.WalletAdder;
import com.eshoppingZone.ewallet.repository.EwalletRepository;
import com.eshoppingZone.ewallet.repository.StatementsRepository;
import com.razorpay.PaymentLink;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;
@Service
public class EwalletServiceImpl implements EwalletService {
    @Autowired
    private EwalletRepository ewalletRepository;
    
    @Autowired
    private StatementsRepository statementsRepository;
    
    
    
    @Override
    public List<Ewallet> getWallets() {
        return ewalletRepository.findAll();
    }

        @Override
        public Ewallet addWallet(Ewallet wallet) {
            return ewalletRepository.save(wallet);
        }

        @Override
        public void addMoney(Integer walletId, Double amount, String transactionRemarks) throws WalletNotFoundException {
            Ewallet wallet = getById(walletId);
            wallet.setCurrentBal(wallet.getCurrentBal() + amount);
            if (wallet.getStatements()==null){
                wallet.setStatements(new ArrayList<>());
            }
            wallet.getStatements().add(new Statement(
            	    null,  // statementId (Auto-generated)
            	    "Credit",  // transactionType
            	    amount,  // amount
            	    LocalDateTime.now(),  // dateTime
            	    null,  // orderId
            	    transactionRemarks  // transactionRemarks
            	));
            System.out.println(wallet);
            ewalletRepository.save(wallet);
        }

        @Override
        public void updateWallet(Integer profileId, Double amount, String transactionRemarks, String transactionType) throws WalletNotFoundException {
            Ewallet wallet = getWalletByProfileId(profileId);
            
            if (transactionType.equals("Debit") && wallet.getCurrentBal() >= amount) {
                wallet.setCurrentBal(wallet.getCurrentBal() - amount);
            } else if (transactionType.equals("Credit")) {
                wallet.setCurrentBal(wallet.getCurrentBal() + amount);
            }
            if (wallet.getStatements()==null){
                wallet.setStatements(new ArrayList<>());
            }
            wallet.getStatements().add(new Statement(
            	    null,  // statementId (Auto-generated)
            	    transactionType,  // transactionType
            	    amount,  // amount
            	    LocalDateTime.now(),  // dateTime
            	    null, null // orderId
            	      // transactionRemarks
            	));
            ewalletRepository.save(wallet);
        }

		@Override
        public Ewallet getById(Integer walletId) throws WalletNotFoundException {
            return ewalletRepository.findById(walletId).orElseThrow(() -> new WalletNotFoundException("Wallet not found"));
        }
		@Override
		public Ewallet getByProfileId(Integer profileId) throws WalletNotFoundException {
		    return ewalletRepository.findByProfileId(profileId);
		}


        @Override
        public List<Statement> getStatementsById(Integer walletId) throws WalletNotFoundException {
            Ewallet wallet = getById(walletId);
            return wallet.getStatements();
        }

        @Override
        public List<Statement> getStatements() {
            List<Statement> statements = new ArrayList<>();
            List<Ewallet> wallets = getWallets();
            for (Ewallet wallet : wallets) {
                statements.addAll(wallet.getStatements());
            }
            return statements;
        }
        @Override
        public Ewallet getWalletByProfileId(Integer profileId) {
            return ewalletRepository.findByProfileId(profileId);
        }

        @Override
        public String addMoney(WalletAdder walletAdder) {
            System.out.println(walletAdder.toString());
            Ewallet wallet = getWalletByProfileId(walletAdder.getProfileId());
            if (wallet == null){
                wallet = new Ewallet();
                wallet.setCurrentBal(0.0);
            }
            wallet.setProfileId(walletAdder.getProfileId());
            wallet.setCurrentBal(wallet.getCurrentBal() + walletAdder.getAmmount());
            Statement statement = new Statement(
            	    null,  // statementId (Auto-generated)
            	    "online",  // transactionType
            	    walletAdder.getAmmount(),  // amount
            	    LocalDateTime.now(),  // dateTime
            	    null,  // orderId
            	    walletAdder.getRemarks()  // transactionRemarks
            	);
            if (wallet.getStatements()==null){
                wallet.setStatements(new ArrayList<>());
            }
            wallet.getStatements().add(statement);
            System.out.println(wallet);
            ewalletRepository.save(wallet);
            return walletAdder.getAmmount() + "added successfully";
        }

        @Override
        public void deleteById(Integer walletId) throws WalletNotFoundException {
            Ewallet wallet = ewalletRepository.findById(walletId)
                .orElseThrow(() -> new WalletNotFoundException("Wallet not found for " + walletId));
            
            wallet.getStatements().clear();
            ewalletRepository.save(wallet);
            ewalletRepository.deleteById(walletId);
        }
        
        
        
//        razor pay service method to create payment link
        @Override
        public String createPaymentLink(int profileId, double amount) {
        	
        	String keyId="rzp_test_ZCxFKPgSpv6kQ2";
        	String keySecret = "GqXc5GjVPhPHjUYjdcaqHiTS";
        	String callbackUrl = "http://localhost:9195/wallet/callback";
        		
            try {
                RazorpayClient razorpayClient = new RazorpayClient(keyId, keySecret);

                // 🔹 Generate referenceId containing userId, amount, and UUID
                String referenceId = (profileId + "_" + amount + "_" + UUID.randomUUID()).substring(0,40);
                System.out.println(profileId + "" + amount + "" + UUID.randomUUID().toString());

                JSONObject paymentLinkRequest = new JSONObject();
                paymentLinkRequest.put("amount", amount * 100); 
                paymentLinkRequest.put("currency", "INR");
                paymentLinkRequest.put("expire_by", (System.currentTimeMillis() / 1000) + 3600); 
                paymentLinkRequest.put("callback_url", callbackUrl);
                paymentLinkRequest.put("callback_method", "get");
                paymentLinkRequest.put("reference_id", referenceId); 

                PaymentLink paymentLink = razorpayClient.paymentLink.create(paymentLinkRequest);
                return paymentLink.get("short_url"); // Returns the payment link URL
            } catch (RazorpayException e) {
                e.printStackTrace();
                return "Error creating payment link";
                }
        }
        @Override
        public String createOrderPaymentLink(int profileId, double amount, int orderId) {
            String keyId = "rzp_test_ZCxFKPgSpv6kQ2";
            String keySecret = "GqXc5GjVPhPHjUYjdcaqHiTS";
            String callbackUrl = "http://localhost:9194/orders/payment-callback";

            try {
                RazorpayClient razorpayClient = new RazorpayClient(keyId, keySecret);

                String referenceId = "ORDER_" + orderId + "_" + UUID.randomUUID().toString().substring(0, 10);

                JSONObject paymentLinkRequest = new JSONObject();
                paymentLinkRequest.put("amount", amount * 100);
                paymentLinkRequest.put("currency", "INR");
                paymentLinkRequest.put("expire_by", (System.currentTimeMillis() / 1000) + 3600);
                paymentLinkRequest.put("callback_url", callbackUrl);
                paymentLinkRequest.put("callback_method", "get");
                paymentLinkRequest.put("reference_id", referenceId);
                paymentLinkRequest.put("description", "Payment for Order ID: " + orderId);

                PaymentLink paymentLink = razorpayClient.paymentLink.create(paymentLinkRequest);
                return paymentLink.get("short_url");
            } catch (RazorpayException e) {
                e.printStackTrace();
                return "Error creating payment link";
            }
        }

        @Override
        public Ewallet createwallet(int profileId) {
        	
        	Ewallet wal = new Ewallet(
        			0.0,null,profileId);
        	
        	return ewalletRepository.save(wal);
        	
        }



    
//    
//    @Override
//    public Ewallet createWallet(int profileId) {
//    	Ewallet ewallet = new Ewallet();
//    	ewallet.setCurrentBal(0.0);
//    	ewallet.setProfileId(profileId);
//    	
//        return ewalletRepository.save(ewallet);
//    }
//    
//    @Override
//    public void addMoney(Integer walletId, Double amount) {
//        Ewallet ewallet = ewalletRepository.findById(walletId).orElseThrow();
//        ewallet.setCurrentBal(ewallet.getCurrentBal() + amount);
//        ewalletRepository.save(ewallet);
//        
//        Statement statement = new Statement();
//        statement.setTransactionType("Deposit");
        
//        statement.setAmount(amount);
//        statement.setDateTime(LocalDateTime.now());
//        statement.setEwallet(ewallet);
//        statementsRepository.save(statement);
//    }
//    @Override
//    public double deduct(Integer walletId, double amount) {
//        Ewallet wallet = ewalletRepository.findById(walletId)
//            .orElseThrow(() -> new RuntimeException("Wallet not found"));
//
//        if (wallet.getCurrentBal() >= amount) {
//            wallet.setCurrentBal(wallet.getCurrentBal() - amount);
//            ewalletRepository.save(wallet);
//            return wallet.getCurrentBal(); // Return updated balance
//        } else {
//            throw new RuntimeException("Insufficient balance");
//        }
//    }
//    
//    @Override
//    public List<Statement> getStatementsByWalletId(Integer walletId) {
//        return statementsRepository.findAll();
//    }
//    
//    @Override
//    public void deleteById(Integer walletId) {
//        ewalletRepository.deleteById(walletId);
//    }
//
//	@Override
//	public List<Statement> getStatements() {
//		// TODO Auto-generated method stub
//		return statementsRepository.findAll();
//	}
////
////	@Override
////	public Integer getWalletId(Integer walletId) {
////		// TODO Auto-generated method stub
////		return ewalletRepository.findById(walletId);

	
		
		
}
