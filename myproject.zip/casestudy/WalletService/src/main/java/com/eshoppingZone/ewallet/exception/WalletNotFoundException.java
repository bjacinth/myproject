package com.eshoppingZone.ewallet.exception;

public class WalletNotFoundException extends RuntimeException {
	
	public WalletNotFoundException(String message) {
		// TODO Auto-generated constructor stub
	
		super(message);
	}
	

}
