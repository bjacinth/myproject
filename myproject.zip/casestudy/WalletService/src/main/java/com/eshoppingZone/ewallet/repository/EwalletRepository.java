package com.eshoppingZone.ewallet.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eshoppingZone.ewallet.pojo.Ewallet;

public interface EwalletRepository extends JpaRepository<Ewallet, Integer>{

	Ewallet findByProfileId(Integer profileId);

}
