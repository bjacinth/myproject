package com.eshoppingZone.ewallet.pojo;

public class WalletAdder {
	private int profileId;
	private Double ammount;
	private String remarks;
	public WalletAdder(int profileId, Double ammount, String remarks) {
		super();
		this.profileId = profileId;
		this.ammount = ammount;
		this.remarks = remarks;
	}
	public WalletAdder() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getProfileId() {
		return profileId;
	}
	public void setProfileId(int profileId) {
		this.profileId = profileId;
	}
	public Double getAmmount() {
		return ammount;
	}
	public void setAmmount(Double ammount) {
		this.ammount = ammount;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	

}
