package com.eshoppingZone.ewallet.resource;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.eshoppingZone.ewallet.pojo.Ewallet;
import com.eshoppingZone.ewallet.pojo.Statement;
import com.eshoppingZone.ewallet.pojo.WalletAdder;
import com.eshoppingZone.ewallet.resource.WallerResource;
import com.eshoppingZone.ewallet.service.EwalletService;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(MockitoExtension.class)
class WallerResourceTest {

    private MockMvc mockMvc;

    @Mock
    private EwalletService ewalletService;

    @InjectMocks
    private WallerResource wallerResource;

    private Ewallet wallet;
    private Statement statement;
    private WalletAdder walletAdder;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(wallerResource).build();

        wallet = new Ewallet();
        wallet.setWalletId(1);
        wallet.setProfileId(100);
        wallet.setCurrentBal(500.0);
        wallet.setStatements(Arrays.asList(
            new Statement(1, "Credit", 200.0, LocalDateTime.now(), null, "Test Credit"),
            new Statement(2, "Debit", 100.0, LocalDateTime.now(), null, "Test Debit")
        ));

        statement = new Statement();
        statement.setTransactionType("Credit");
        statement.setAmount(100.0);
        statement.setDateTime(LocalDateTime.now());

        walletAdder = new WalletAdder();
        walletAdder.setProfileId(100);
        walletAdder.setAmmount(300.0);
        walletAdder.setRemarks("Wallet Add Test");
    }

    @Test
    void testGetWallets() throws Exception {
        when(ewalletService.getWallets()).thenReturn(Arrays.asList(wallet));

        mockMvc.perform(get("/wallet/all"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(1));

        verify(ewalletService, times(1)).getWallets();
    }

    @Test
    void testAddWallet() throws Exception {
        when(ewalletService.addWallet(any(Ewallet.class))).thenReturn(wallet);

        mockMvc.perform(post("/wallet/addwallet")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(wallet)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.walletId").value(wallet.getWalletId()));

        verify(ewalletService, times(1)).addWallet(any(Ewallet.class));
    }

    @Test
    void testAddMoneyByPathVariable() throws Exception {
        doNothing().when(ewalletService).addMoney(1, 200.0, "Deposit");

        mockMvc.perform(post("/wallet/addmoney/1/200.0/Deposit"))
                .andExpect(status().isOk());

        verify(ewalletService, times(1)).addMoney(1, 200.0, "Deposit");
    }

    @Test
    void testUpdateWallet() throws Exception {
        doNothing().when(ewalletService).updateWallet(100, 300.0, "Test Credit", "Credit");

        mockMvc.perform(put("/wallet/update/100/300.0/Test Credit/Credit"))
                .andExpect(status().isOk());

        verify(ewalletService, times(1)).updateWallet(100, 300.0, "Test Credit", "Credit");
    }

    @Test
    void testAddMoneyByRequestBody() throws Exception {
        when(ewalletService.addMoney(any(WalletAdder.class))).thenReturn("300.0 added successfully");

        mockMvc.perform(post("/wallet/addmoney")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(walletAdder)))
                .andExpect(status().isOk())
                .andExpect(content().string("300.0 added successfully"));

        verify(ewalletService, times(1)).addMoney(any(WalletAdder.class));
    }

    @Test
    void testDeleteWallet() throws Exception {
        doNothing().when(ewalletService).deleteById(1);

        mockMvc.perform(delete("/wallet/delete/id/1"))
                .andExpect(status().isOk());

        verify(ewalletService, times(1)).deleteById(1);
    }

    @Test
    void testGetById() throws Exception {
        when(ewalletService.getById(1)).thenReturn(wallet);

        mockMvc.perform(get("/wallet/walletId/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.walletId").value(wallet.getWalletId()));

        verify(ewalletService, times(1)).getById(1);
    }

    @Test
    void testGetStatementsById() throws Exception {
        when(ewalletService.getStatementsById(1)).thenReturn(wallet.getStatements());

        mockMvc.perform(get("/wallet/statments/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(2));

        verify(ewalletService, times(1)).getStatementsById(1);
    }

    @Test
    void testGetStatements() throws Exception {
        List<Statement> statements = Arrays.asList(statement);
        when(ewalletService.getStatements()).thenReturn(statements);

        mockMvc.perform(get("/wallet/statements"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(1));

        verify(ewalletService, times(1)).getStatements();
    }

    @Test
    void testGetWalletByProfileId() throws Exception {
        when(ewalletService.getWalletByProfileId(100)).thenReturn(wallet);

        mockMvc.perform(get("/wallet/profileId/100"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.profileId").value(wallet.getProfileId()));

        verify(ewalletService, times(1)).getWalletByProfileId(100);
    }
}
