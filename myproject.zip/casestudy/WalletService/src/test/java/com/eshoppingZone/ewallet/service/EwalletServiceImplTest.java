package com.eshoppingZone.ewallet.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.time.LocalDateTime;
import java.util.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.eshoppingZone.ewallet.exception.WalletNotFoundException;
import com.eshoppingZone.ewallet.pojo.Ewallet;
import com.eshoppingZone.ewallet.pojo.Statement;
import com.eshoppingZone.ewallet.repository.EwalletRepository;
import com.eshoppingZone.ewallet.service.EwalletServiceImpl;

class EwalletServiceImplTest {

    @InjectMocks
    private EwalletServiceImpl ewalletService;

    @Mock
    private EwalletRepository ewalletRepository;

    private Ewallet mockWallet;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        mockWallet = new Ewallet();
        mockWallet.setWalletId(1);
        mockWallet.setProfileId(1001);
        mockWallet.setCurrentBal(500.0);
        mockWallet.setStatements(new ArrayList<>()); 
        }

    @Test
    void testGetById_Success() throws WalletNotFoundException {
        when(ewalletRepository.findById(1)).thenReturn(Optional.of(mockWallet));

        Ewallet wallet = ewalletService.getById(1);

        assertNotNull(wallet);
        assertEquals(1, wallet.getWalletId());
        verify(ewalletRepository, times(1)).findById(1);
    }

    @Test
    void testGetById_WalletNotFound() {
        when(ewalletRepository.findById(2)).thenReturn(Optional.empty());

        assertThrows(WalletNotFoundException.class, () -> ewalletService.getById(2));
        verify(ewalletRepository, times(1)).findById(2);
    }

    @Test
    void testAddMoney() throws WalletNotFoundException {
        when(ewalletRepository.findById(1)).thenReturn(Optional.of(mockWallet));
        when(ewalletRepository.save(any(Ewallet.class))).thenReturn(mockWallet);

        ewalletService.addMoney(1, 200.0, "Test Credit");

        assertEquals(700.0, mockWallet.getCurrentBal()); 
        assertEquals(1, mockWallet.getStatements().size()); 
        assertEquals("Credit", mockWallet.getStatements().get(0).getTransactionType());

        verify(ewalletRepository, times(1)).save(mockWallet);
    }

    @Test
    void testUpdateWallet_Debit_Success() throws WalletNotFoundException {
        when(ewalletRepository.findByProfileId(1001)).thenReturn(mockWallet);
        when(ewalletRepository.save(any(Ewallet.class))).thenReturn(mockWallet);

        ewalletService.updateWallet(1001, 100.0, "Test Debit", "Debit");

        assertEquals(400.0, mockWallet.getCurrentBal()); 
        assertEquals(1, mockWallet.getStatements().size());

        verify(ewalletRepository, times(1)).save(mockWallet);
    }

    @Test
    void testUpdateWallet_Debit_InsufficientBalance() {
        when(ewalletRepository.findByProfileId(1001)).thenReturn(mockWallet);

        ewalletService.updateWallet(1001, 600.0, "Test Debit", "Debit");

        assertEquals(500.0, mockWallet.getCurrentBal()); 
        assertEquals(0, mockWallet.getStatements().size());
    }

    @Test
    void testUpdateWallet_Credit() throws WalletNotFoundException {
        when(ewalletRepository.findByProfileId(1001)).thenReturn(mockWallet);
        when(ewalletRepository.save(any(Ewallet.class))).thenReturn(mockWallet);

        ewalletService.updateWallet(1001, 200.0, "Test Credit", "Credit");

        assertEquals(700.0, mockWallet.getCurrentBal()); 
        assertEquals(1, mockWallet.getStatements().size()); 

        verify(ewalletRepository, times(1)).save(mockWallet);
    }

    @Test
    void testDeleteById() throws WalletNotFoundException {
        when(ewalletRepository.findById(1)).thenReturn(Optional.of(mockWallet));

        ewalletService.deleteById(1);

        verify(ewalletRepository, times(1)).deleteById(1);
    }
}
