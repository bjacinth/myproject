import './App.css';
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import HomePage from './Components/pages/Homepage.jsx';
import AddProduct from "./Components/pages/AddProduct.jsx";
import Headers from './Components/headersandfooters/Header.jsx'
import Footer from './Components/headersandfooters/Footer.jsx'
import ProductPage from './Components/pages/ProductPage.jsx'
import LoginPage from './Components/pages/LoginPage.jsx'
import SignUp from './Components/pages/SignUpPage.jsx'
import ProfilePage from './Components/pages/ProfilePage.jsx';
import WalletPage from './Components/pages/WalletPage.jsx';
import CartPage from './Components/pages/CartPage.jsx';
import OrderPage from './Components/pages/OrderPage.jsx';
import OrdersList from './Components/pages/OrdersList.jsx';
import PaymentSuccess from './Components/pages/PaymentSuccess.jsx';
import AboutUsPage from './Components/pages/AboutUSPage.jsx';
import Merchant from './Components/pages/Merchant.jsx';
import ContactUsPage from './Components/pages/ContactUsPage.jsx';
import PrivacyPolicy from './Components/pages/PrivacyPolicy.jsx';

const App = () => {
  return (
    <div>

      <Router>
        <Headers />

        <Routes>
          <Route path="/" element={<HomePage />} />

          <Route path="/home" element={<HomePage />} />

          <Route path="/login" element={<LoginPage />} />

          <Route path='/register' element={<SignUp />} />

          <Route path="/product/:productId" element={<ProductPage />} />

          <Route path="/wallet/walletId/:walletId" element={<WalletPage />} />

          <Route path="/cart/profileid/:profileId" element={<CartPage />} />

          <Route path="/profile/id/:profileId" element={<ProfilePage />} />

          <Route path="/merchant/add" element={<AddProduct />} />

          <Route path="/orders/:profileId" element={<OrderPage />} />

          <Route path="/orders/customer/:profileId" element={<OrdersList />} />

          <Route path="/payment-success" element={<PaymentSuccess />} />

          <Route path="/merchant" element={<Merchant />} />

          <Route path='/about' element={<AboutUsPage/>} />

          <Route path="/contact" element={<ContactUsPage />} />

          <Route path="/privacy" element={<PrivacyPolicy />} />


        </Routes>
      </Router>
      <Footer />
    </div>

  );
};

export default App;

