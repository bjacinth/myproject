import React from 'react';
import '../cssfiles/ContactUsPage.css';

const ContactUs = () => {
  return (
    <div className="contact-container">
      <div className="contact-card">
        <h1 className="contact-title">Contact Us</h1>
        <p className="contact-subtitle">We’d love to hear from you! Reach out with any questions, feedback, or support needs.</p>

        <div className="contact-content">
          <form className="contact-form">
            <input type="text" className="contact-input" placeholder="Your Name" required />
            <input type="email" className="contact-input" placeholder="Your Email" required />
            <input type="text" className="contact-input" placeholder="Subject" />
            <textarea className="contact-textarea" placeholder="Your Message" required></textarea>
            <button type="submit" className="contact-button">Send Message</button>
          </form>

          <div className="contact-info">
            <h3>📍 Our Office</h3>
            <p>Jmart Pvt. Ltd.<br />123 Market Street<br />Mumbai, Maharashtra, India</p>

            <h3>📞 Call Us</h3>
            <p>+91 9815965588</p>

            <h3>📧 Email</h3>
            <p>support@Jmart.com</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactUs;
