import React from 'react';
import '../cssfiles/PrivacyPolicy.css'; 

const PrivacyPolicy = () => {
  return (
    <div className="privacy-container">
      <div className="privacy-card">
        <h1 className="privacy-title">Privacy Policy</h1>
        <p className="privacy-updated">Last updated: June 13, 2025</p>

        <section className="privacy-section">
          <h2>1. Introduction</h2>
          <p>
            At <strong>Jmart</strong>, we value your privacy and are committed to protecting your personal information. This Privacy Policy explains how we collect, use, and safeguard your data when you use our website and services.
          </p>
        </section>

        <section className="privacy-section">
          <h2>2. Information We Collect</h2>
          <ul>
            <li>Personal details (name, email, phone number, address)</li>
            <li>Account credentials (username, password)</li>
            <li>Payment information (processed securely via third-party gateways)</li>
            <li>Browsing behavior and device information</li>
          </ul>
        </section>

        <section className="privacy-section">
          <h2>3. How We Use Your Information</h2>
          <p>We use your data to:</p>
          <ul>
            <li>Process orders and payments</li>
            <li>Provide customer support</li>
            <li>Send updates, offers, and newsletters</li>
            <li>Improve our website and services</li>
          </ul>
        </section>

        <section className="privacy-section">
          <h2>4. Data Sharing & Security</h2>
          <p>
            We do not sell your personal data. We may share it with trusted partners for order fulfillment, payment processing, and analytics. All data is encrypted and stored securely.
          </p>
        </section>

        <section className="privacy-section">
          <h2>5. Your Rights</h2>
          <p>You have the right to:</p>
          <ul>
            <li>Access and update your personal data</li>
            <li>Request deletion of your account</li>
            <li>Opt out of marketing communications</li>
          </ul>
        </section>

        <section className="privacy-section">
          <h2>6. Cookies</h2>
          <p>
            We use cookies to enhance your browsing experience. You can manage cookie preferences through your browser settings.
          </p>
        </section>

        <section className="privacy-section">
          <h2>7. Contact Us</h2>
          <p>
            If you have any questions about this Privacy Policy, please contact us at:
            <br />
            📧 <a href="mailto:privacy@Jmart.com">privacy@Jmart.com</a>
          </p>
        </section>
      </div>
    </div>
  );
};

export default PrivacyPolicy;
