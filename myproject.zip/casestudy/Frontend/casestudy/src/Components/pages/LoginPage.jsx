import React, { useEffect, useState } from 'react';
import '../cssfiles/LoginPage.css';
import { useNavigate } from 'react-router-dom';
import jmartImage from '../../loginimage.jpeg';
// import jmartImage from '../../loginimage2.jpeg';
const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();
  useEffect(() => {
    const profileId = localStorage.getItem("profileId");
    const role = localStorage.getItem("role");

    if (profileId && role) {
      switch (role) {
        case "Customer":
          navigate("/home");
          break;
        case "Merchant":
          navigate("/merchant");
          break;
        case "DeliveryAgent":
          navigate("/delivery");
          break;
        default:
          console.warn("Unknown role in localStorage");
      }
    }
  }, []);




  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch(`http://localhost:9191/profile/emailId/${email}`);
      if (!response.ok) {
        throw new Error("User not found");
      }

      const profile = await response.json();

      if (profile.password === password) {
        localStorage.setItem("profileId", profile.profileId);
        localStorage.setItem("role", profile.role); // Store role


        // Role-based navigation
        switch (profile.role) {
          case "Customer":
            navigate("/home");
            break;
          case "Merchant":
            navigate("/merchant");
            break;
          case "DeliveryAgent":
            navigate("/delivery");
            break;
          default:
            alert("Unknown role. Please contact support.");
        }
      } else {
        alert("Incorrect password");
      }
    } catch (error) {
      console.error("Login error:", error);
      alert("Login failed. Please check your credentials.");
    }
  };


  return (
    <div className="login-container">
      <div className="image-section">
        <img src={jmartImage} alt="JMart" />
      </div>
      <div className="login-box">
        <h2>Login</h2>
        <form onSubmit={handleSubmit}>
          <div className="input-group">
            <label>Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div className="input-group">
            <label>Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          <button className='login1' type="submit">Login</button>
          <span><p>Don't have an account?</p><h4 className='signup' onClick={() => navigate("/register")}>SignUp</h4></span>
          <div className="social-login">
            <p>Or login with</p>
            <div className="social-buttons">
              <button type="button" className="google-btn">
                <i className="fab fa-google"></i> Google
              </button>
              <button type="button" className="github-btn">
                <i className="fab fa-github"></i> GitHub
              </button>
            </div>
          </div>

        </form>
      </div>
    </div>
  );
};

export default Login;
