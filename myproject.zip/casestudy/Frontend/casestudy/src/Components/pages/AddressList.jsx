import styles from "../cssfiles/ProfilePage.css";

const AddressList = ({ addresses }) => {
    if (!addresses || addresses.length === 0) {
        return <p>No addresses available.</p>;
    }

    return (
        <div className={styles.addressSection}>
            <h3>Addresses</h3>
            {addresses.map((addr) => (
                <div key={addr.addressId} className={styles.addressCard}>
                    <p><strong>House No:</strong> {addr.houseNumber}</p>
                    <p><strong>Street:</strong> {addr.streetName}</p>
                    <p><strong>Colony:</strong> {addr.colonyName}</p>
                    <p><strong>City:</strong> {addr.city}</p>
                    <p><strong>State:</strong> {addr.state}</p>
                    <p><strong>Pincode:</strong> {addr.pincode}</p>
                </div>
            ))}
        </div>
    );
};

export default AddressList;
