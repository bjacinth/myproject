import { useState } from "react";
import { useNavigate } from "react-router-dom";
import '../cssfiles/SignUpPage.css';

const ProfileForm = () => {
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        fullName: "",
        emailId: "",
        mobileNumber: "",
        about: "",
        dateOfBirth: "",
        gender: "",
        password: "",
        image: "",
        role: "",
        address: {
            houseNumber: "",
            streetName: "",
            colonyName: "",
            city: "",
            state: "",
            pincode: ""
        }
    });

    const [showSuccess, setShowSuccess] = useState(false);

    const handleChange = (e) => {
        const { name, value } = e.target;
        if (name in formData.address) {
            setFormData({
                ...formData,
                address: {
                    ...formData.address,
                    [name]: value
                }
            });
        } else {
            setFormData({ ...formData, [name]: value });
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        const payload = {
            ...formData,
            address: [
                {
                    ...formData.address,
                    houseNumber: parseInt(formData.address.houseNumber),
                    pincode: parseInt(formData.address.pincode)
                }
            ]
        };

        try {
            const response = await fetch("http://localhost:9191/profile/addCustomer", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(payload)
            });

            if (!response.ok) throw new Error("Failed to create profile");

            const data = await response.json();
            localStorage.setItem("profileId", data.profileId);
            setShowSuccess(true);
            setTimeout(() => navigate("/home"), 2000);
        } catch (error) {
            console.error("Error:", error.message);
        }
    };

    return (
        <div className="signup-container">
            <form className="signup-form modern-card" onSubmit={handleSubmit}>
                <h2 className="form-title">🚀 Create Your Profile</h2>

                <div className="form-grid">
                    <input className="form-input" type="text" name="fullName" onChange={handleChange} placeholder="Full Name" required />
                    <input className="form-input" type="email" name="emailId" onChange={handleChange} placeholder="Email" required />
                    <input className="form-input" type="text" name="mobileNumber" onChange={handleChange} placeholder="Mobile Number" required />
                    <input className="form-input" type="date" name="dateOfBirth" onChange={handleChange} required />
                    <select className="form-select" name="gender" onChange={handleChange} required>
                        <option value="">Select Gender</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Other">LGBTQ+</option>
                    </select>
                    <input className="form-input" type="password" name="password" onChange={handleChange} placeholder="Password" required />
                    <input className="form-input" type="text" name="image" onChange={handleChange} placeholder="Profile Image Filename" required />
                    <select className="form-select" name="role" onChange={handleChange} required>
                        <option value="">Select Role</option>
                        <option value="Customer">Customer</option>
                        <option value="Merchant">Merchant</option>
                        <option value="DeliveryAgent">Delivery Agent</option>
                    </select>
                </div>

                <textarea className="form-textarea" name="about" onChange={handleChange} placeholder="Tell us about yourself..." />


                <button className="submit-button" type="submit">✨ Create Profile</button>

                {showSuccess && (
                    <div className="success-popup">
                        <p>🎉 Profile created successfully! Redirecting to home...</p>
                    </div>
                )}
            </form>
        </div>
    );
};

export default ProfileForm;
