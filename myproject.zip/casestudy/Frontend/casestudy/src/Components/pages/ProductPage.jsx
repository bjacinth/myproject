import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import "../cssfiles/ProductPage.css";
import DropdownMenu from "../pages/Dropdown.jsx";
import { useNavigate } from "react-router-dom";

const ProductPage = () => {
    const { productId } = useParams(); 
    const [product, setProduct] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [quantity, setQuantity] = useState(1); 
    const [addedToCart, setAddedToCart] = useState(false);
    const navigate = useNavigate();
    const [currentImageIndex, setCurrentImageIndex] = useState(0); 
    const profileId = localStorage.getItem("profileId");


    const StarRating = ({ rating }) => {
        const fullStars = Math.floor(rating);
        const halfStar = rating % 1 >= 0.5;
        const emptyStars = 5 - fullStars - (halfStar ? 1 : 0);

        return (
            <div style={{ color: '#FFD700' }}>
                {'★'.repeat(fullStars)}
                {halfStar && '☆'}
                {'☆'.repeat(emptyStars)}
            </div>
        );
    };

    useEffect(() => {
        const fetchProduct = async () => {
            try {
                const response = await axios.get(`http://localhost:9192/product/id/${productId}`);
                setProduct(response.data);
            } catch (err) {
                setError("Failed to fetch product data.");
            } finally {
                setLoading(false);
            }
        };

        fetchProduct();
    }, [productId]);

    const increaseQuantity = () => {
        setQuantity(prevQuantity => prevQuantity + 1);
    };

    const decreaseQuantity = () => {
        setQuantity(prevQuantity => (prevQuantity > 1 ? prevQuantity - 1 : 1));
    };

    const addToCart = async () => {
        if (!profileId) {
            alert("Please log in to add items to your cart.");
            return;
        }

        try {
            const cartUrl = `http://localhost:9193/cart/add/${profileId}/${productId}/${quantity}`;
            const response = await axios.post(cartUrl);

            console.log("Cart updated:", response.data);
            setAddedToCart(true); 
        } catch (error) {
            console.error("Error adding to cart:", error);
            alert("Failed to add product to cart. Please try again.");
        }
    };

    const handleCartButtonClick = () => {
        if (addedToCart) {
            navigate(`/cart/profileId/${profileId}`);
        } else {
            addToCart();
        }
    };

    const nextImage = () => {
        setCurrentImageIndex((prevIndex) => (prevIndex + 1) % product.image.length);
    };

    const prevImage = () => {
        setCurrentImageIndex((prevIndex) => (prevIndex - 1 + product.image.length) % product.image.length);
    };

    if (loading) return <h2>Loading product...</h2>;
    if (error) return <h2>{error}</h2>;

    return (
        <>
            <div className="header">
                <div>
                    <DropdownMenu />
                </div>

            </div>
            <div className="product-wrapper">
                <div className="product-container">
                    <div className="carousel-container">
                        <button onClick={prevImage} className="carousel-btn">◄</button>
                        <img src={product.image[currentImageIndex]} alt={product.name} className="product-image" />
                        <button onClick={nextImage} className="carousel-btn">►</button>
                    </div>



                    <h1>{product.productName}</h1>
                    <p>{product.productType}</p>
                    <h2>₹{product.price}</h2>

                    <div className="quantity-selector">
                        <button onClick={decreaseQuantity} className="quantity-btn">-</button>
                        <span>{quantity}</span>
                        <button onClick={increaseQuantity} className="quantity-btn">+</button>
                    </div>


                    <button onClick={handleCartButtonClick} className="add-to-cart-btn">
                        {addedToCart ? "Go to Cart" : "Add to Cart"}
                    </button>

                </div>
                <div className="productspec">
                    <div className="product-container1">
                        <h1>Product Details</h1>
                        <p>{product.description}</p>

                        <table className="productTable" title="Specifications">
                            <tbody>
                                {Object.entries(product.specification || {}).map(([key, value]) => (
                                    <tr key={key}>
                                        <td className="td" style={{ fontWeight: "bold", padding: "8px", border: "1px solid #ccc" }}>{key}</td>
                                        <td className="td" style={{ padding: "8px", border: "1px solid #ccc" }}>{value}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>

                    </div>
                    <div className="product-container2">
                        <h3>Ratings & Reviews</h3>
                        {Object.keys(product.rating).map(profileId => (
                            <div key={profileId} style={{ marginBottom: '1rem' }}>
                                <h4>Profile ID: {profileId}</h4>
                                <StarRating rating={product.rating[profileId]} />
                                <p>{product.review[profileId]}</p>

                            </div>
                        ))}



                    </div>

                </div>


            </div>

        </>

    );
};

export default ProductPage;