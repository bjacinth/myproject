import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import '../cssfiles/OrdersList.css';
import Dropdown from '../pages/Dropdown.jsx';

const OrdersList = () => {
  const { profileId } = useParams();
  const [orders, setOrders] = useState([]);
  const [error, setError] = useState(null);
  const [cancelledOrders, setCancelledOrders] = useState(new Set());
  const [productImages, setProductImages] = useState({});
  const [selectedOrder, setSelectedOrder] = useState(null);

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const res = await fetch(`http://localhost:9194/orders/customer/${profileId}`);
        if (!res.ok) throw new Error('Failed to fetch orders');
        const data = await res.json();
        setOrders(data);
        await fetchProductImages(data);
      } catch (err) {
        console.error(err);
        setError('Could not load orders.');
      }
    };

    fetchOrders();
  }, [profileId]);

  const fetchProductImages = async (orders) => {
    const images = {};
    for (const order of orders) {
      for (const item of order.items) {
        if (!images[item.productId]) {
          try {
            const res = await fetch(`http://localhost:9192/product/${item.productId}`);
            if (res.ok) {
              const product = await res.json();
              images[item.productId] = product.image?.[0];
            }
          } catch (err) {
            console.error(`Failed to fetch image for product ${item.productId}`, err);
          }
        }
      }
    }
    setProductImages(images);
  };

  const handleCancelOrder = async (orderId) => {
    try {
      const res = await fetch(`http://localhost:9194/orders/${orderId}/status?status=Cancel`, {
        method: 'PUT',
      });
      if (!res.ok) throw new Error('Failed to cancel order');
      setCancelledOrders((prev) => new Set(prev).add(orderId));
    } catch (err) {
      console.error(err);
      alert('Failed to cancel the order. Please try again.');
    }
  };

  const openModal = (order) => setSelectedOrder(order);
  const closeModal = () => setSelectedOrder(null);

  if (error) {
    return <div className="orders-container">Error: {error}</div>;
  }

  if (orders.length === 0) {
    return (
      <>
        <div className="header"><Dropdown /></div>
        <div className="orders-container no-orders">
          <div className="no-orders-animation">
            <lottie-player
              src="/animations/noOrders.json"
              background="transparent"
              speed="1"
              style={{ width: '300px', height: '300px' }}
              loop
              autoplay
            ></lottie-player>
            <h1>No previous orders found.</h1>
            <p>It seems you haven't placed any orders yet.</p>
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      <div className="header"><Dropdown /></div>
      <div className="orders-container">
        <h1>📦 Your Orders</h1>
        {orders.map((order) => (
          <div key={order.orderId} className="order-card" onClick={() => openModal(order)}>
            <h3>Order #{order.orderId}</h3>
            <p><strong>Date:</strong> {order.orderDate}</p>
            <p>
              <strong>Status:</strong>{' '}
              <span className={`order-status ${order.orderStatus === 'Cancel' ? 'cancelled' : ''}`}>
                {order.orderStatus}
              </span>
            </p>
            <p><strong>Amount Paid:</strong> ₹{order.ammountPaid.toFixed(2)}</p>
            <p><strong>Payment Mode:</strong> {order.modeOfPayment}</p>
            <p><strong>Shipping Address:</strong> {order.address.city}, {order.address.state} - {order.address.pincode}</p>
          </div>
        ))}
      </div>

      {selectedOrder && (
        <div className="modal-overlay" onClick={closeModal}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <button className="close-button" onClick={closeModal}>×</button>
            <h2>Order #{selectedOrder.orderId}</h2>
            <p><strong>Date:</strong> {selectedOrder.orderDate}</p>
            <p><strong>Status:</strong> {selectedOrder.orderStatus}</p>
            <p><strong>Amount Paid:</strong> ₹{selectedOrder.ammountPaid.toFixed(2)}</p>
            <p><strong>Payment Mode:</strong> {selectedOrder.modeOfPayment}</p>
            <p><strong>Shipping Address:</strong> {selectedOrder.address.city}, {selectedOrder.address.state} - {selectedOrder.address.pincode}</p>
            <h4>Items:</h4>
            <ul className="modal-items-list">
  {selectedOrder.items.map((item, index) => (
    <li key={index} className="modal-item">
      <img
        src={productImages[item.productId] || '/images/placeholder.png'}
        alt={item.productName}
        className="modal-thumbnail"
      />
      <div className="modal-item-details">
        <span className="product-name">{item.productName}</span>
        <span>× {item.quantity}</span>
        <span>₹{item.price.toFixed(2)}</span>
      </div>
    </li>
  ))}
</ul>

            {!cancelledOrders.has(selectedOrder.orderId) && selectedOrder.orderStatus !== 'Cancel' && (
              <button
                className="cancel-button"
                onClick={() => {
                  handleCancelOrder(selectedOrder.orderId);
                  closeModal();
                }}
              >
                Cancel Order
              </button>
            )}
          </div>
        </div>
      )}
    </>
  );
};

export default OrdersList;
