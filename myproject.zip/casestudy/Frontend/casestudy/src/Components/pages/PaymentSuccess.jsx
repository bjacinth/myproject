import React, { useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import axios from 'axios';

const PaymentSuccess = () => {
    const [searchParams] = useSearchParams();
    const navigate = useNavigate();

    useEffect(() => {
        const handlePaymentSuccess = async () => {
            const referenceId = searchParams.get("reference_id");
            const paymentId = searchParams.get("razorpay_payment_id");
           console.log(searchParams);
           
            if (!referenceId || !paymentId) {
                navigate("/home");
                return;
            }

            try {
                const response = await axios.get("http://localhost:9194/orders/payment-callback", {
                    params: {
                        reference_id: referenceId,
                        razorpay_payment_id: paymentId
                    }
                });

                alert("✅ Payment successful! Order confirmed.");
                navigate("/home");
            } catch (error) {
                console.error("Payment callback failed:", error);
                alert("❌ Payment verification failed.");
                navigate("/home");
            }
        };

        handlePaymentSuccess();
    }, [searchParams, navigate]);

    return (
        <div style={{ textAlign: 'center', marginTop: '50px' }}>
            <h2>Processing your payment...</h2>
            <p>Please wait while we confirm your order.</p>
        </div>
    );
};

export default PaymentSuccess;
