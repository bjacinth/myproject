import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import styles from "../cssfiles/ProfilePage.module.css";
import axios from "axios";
import DropdownMenu from "./Dropdown";

const ProfilePage = () => {
  const { profileId } = useParams();
  const [profile, setProfile] = useState(null);
  const [showPopup, setShowPopup] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  const [newAddress, setNewAddress] = useState({
    houseNumber: "",
    streetName: "",
    colonyName: "",
    city: "",
    state: "",
    pincode: ""
  });
  const [addresses, setAddresses] = useState([]);
  const [primaryIndex, setPrimaryIndex] = useState(null);

  const toggleDarkMode = () => setDarkMode(!darkMode);

  const handleChange = (e) => {
    setNewAddress({ ...newAddress, [e.target.name]: e.target.value });
  };

  const handleSubmit = async () => {
    try {
      await axios.post(`http://localhost:9191/profile/address/add/${profileId}`, newAddress);
      const updatedProfile = await axios.get(`http://localhost:9191/profile/id/${profileId}`);
      setAddresses(updatedProfile.data.address);
      setShowPopup(false);
    } catch (error) {
      console.error("Error adding address:", error);
    }
  };

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const response = await axios.get(`http://localhost:9191/profile/id/${profileId}`);
        setProfile(response.data);
        setAddresses(response.data.address || []);
      } catch (error) {
        console.error("Error fetching profile:", error);
      }
    };

    fetchProfile();
  }, [profileId]);

  if (!profile) return <div className={styles.loading}>Loading profile...</div>;

  return (
    <>
      <div className="header">
        <DropdownMenu />
        <button onClick={toggleDarkMode} className={styles.darkModeToggle}>
          {darkMode ? "☀️ Light Mode" : "🌙 Dark Mode"}
        </button>
      </div>

      <div className={`${styles.profileContainer} ${darkMode ? styles.dark : ""}`}>
        <div className={styles.card}>
          <div className={styles.imageContainer}>
            {profile.image && (
              <img
                src={profile.image}
                alt="Profile"
                className={styles.profileImage}
              />
            )}
          </div>

          <h2 className={styles.profileName}>{profile.fullName}</h2>

          <div className={styles.profileDetailsGrid}>
            <div className={styles.detailBox}>
              <label>Email</label>
              <p>{profile.emailId}</p>
            </div>
            <div className={styles.detailBox}>
              <label>Mobile</label>
              <p>{profile.mobileNumber}</p>
            </div>
            <div className={styles.detailBox}>
              <label>About</label>
              <p>{profile.about}</p>
            </div>
            <div className={styles.detailBox}>
              <label>Date of Birth</label>
              <p>{profile.dateOfBirth}</p>
            </div>
            <div className={styles.detailBox}>
              <label>Gender</label>
              <p>{profile.gender}</p>
            </div>
          </div>

          <div className={styles.addressSection}>
            <h3>Addresses</h3>
            <table className={styles.addressTable}>
              <thead>
                <tr>
                  <th>House No.</th>
                  <th>Street</th>
                  <th>Colony</th>
                  <th>City</th>
                  <th>State</th>
                  <th>Pincode</th>
                  <th>Primary</th>
                </tr>
              </thead>
              <tbody>
                {addresses.map((addr, index) => (
                  <tr key={index}>
                    <td>{addr.houseNumber}</td>
                    <td>{addr.streetName}</td>
                    <td>{addr.colonyName}</td>
                    <td>{addr.city}</td>
                    <td>{addr.state}</td>
                    <td>{addr.pincode}</td>
                    <td>
                      <input
                        type="radio"
                        name="primary"
                        checked={primaryIndex === index}
                        onChange={() => setPrimaryIndex(index)}
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            <button className={styles.addAddressBtn} onClick={() => setShowPopup(true)}>
              + Add New Address
            </button>

            {showPopup && (
              <div className={styles.popupOverlay}>
                <div className={styles.popup}>
                  <h4>Add New Address</h4>
                  {["houseNumber", "streetName", "colonyName", "city", "state", "pincode"].map((field) => (
                    <input
                      key={field}
                      name={field}
                      placeholder={field}
                      value={newAddress[field]}
                      onChange={handleChange}
                      className={styles.inputField}
                    />
                  ))}
                  <button className={styles.popupsubmit} onClick={handleSubmit}>Submit</button>
                  <button className={styles.popupcancel} onClick={() => setShowPopup(false)}>Cancel</button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
};

export default ProfilePage;
