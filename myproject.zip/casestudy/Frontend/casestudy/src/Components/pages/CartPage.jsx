import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import '../cssfiles/CartPage.css';
import Dropdown from '../pages/Dropdown.jsx';

const CartPage = () => {
  const { profileId } = useParams();
  const navigate = useNavigate();
  const [cart, setCart] = useState(null);
  const [wallet, setWallet] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchCart = async () => {
      try {
        const res = await fetch(`http://localhost:9193/cart/profile/${profileId}`);
        if (res.status === 404) {
          setCart({ items: [], totalPrice: 0 });
          return;
        }
        if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
        const data = await res.json();
        setCart(data);
      } catch (err) {
        console.error("Cart fetch error:", err);
        setError("Failed to load cart.");
      }
    };

    const fetchWallet = async () => {
      try {
        const res = await axios.get(`http://localhost:9195/wallet/walletId/${profileId}`);
        setWallet(res.data);
      } catch (err) {
        console.error("Wallet fetch error:", err);
      }
    };

    fetchCart();
    fetchWallet();
  }, [profileId]);

  const updateQuantity = async (index, delta) => {
    const updatedItems = [...cart.items];
    const item = updatedItems[index];
    const newQuantity = Math.max(1, item.quantity + delta);

    try {
      await axios.put(`http://localhost:9193/cart/update/${cart.cartId}/${item.productId}/${newQuantity}`);
      updatedItems[index].quantity = newQuantity;
      const newTotal = updatedItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
      setCart(prevCart => ({ ...prevCart, items: updatedItems, totalPrice: newTotal }));
    } catch (err) {
      console.error("Failed to update quantity in backend:", err);
      alert("Failed to update item quantity. Please try again.");
    }
  };

  const deleteItem = async (productId) => {
    try {
      await axios.delete(`http://localhost:9193/cart/remove/${profileId}/${productId}`);
      const res = await fetch(`http://localhost:9193/cart/profile/${profileId}`);
      const updatedCart = await res.json();
      setCart(updatedCart);
    } catch (err) {
      console.error("Failed to delete item:", err);
      alert("Failed to remove item from cart.");
    }
  };

  const handleCheckout = async () => {
    if (!cart || !cart.items) return;
    try {
      await Promise.all(
        cart.items.map(item =>
          axios.put(`http://localhost:9193/cart/update/${cart.cartId}/${item.productId}/${item.quantity}`)
        )
      );
      const res = await fetch(`http://localhost:9193/cart/profile/${profileId}`);
      const updatedCart = await res.json();
      setCart(updatedCart);
      navigate(`/orders/${profileId}`);
    } catch (err) {
      console.error("Checkout error:", err);
      alert("Failed to update cart. Please try again.");
    }
  };

  if (error) return <div className="cart-container">Error: {error}</div>;
  if (!cart) return <div className="cart-container">Loading cart...</div>;

  return (
    <>
      <div className='header'>
        <Dropdown />
      </div>
      <div className="cart-container">
        <h1>🛒 Your Shopping Cart</h1>

        {wallet && (
          <div className="wallet-balance">
            Wallet Balance: <strong>₹{wallet.currentBal.toLocaleString()}</strong>
          </div>
        )}

        {cart.items.length === 0 ? (
          <div className="empty-cart" style={{ textAlign: 'center', marginTop: '40px' }}>
            <div className="empty-cart-animation">
              <lottie-player
                src="/animations/empty-cart.json"
                background="transparent"
                speed="1"
                style={{ width: '300px', height: '300px' }}
                loop
                autoplay
              ></lottie-player>
              <h2>Your cart is empty!</h2>
              <p>Start adding items to see them here.</p>
            </div>
          </div>
        ) : (
          <>
            <table className="cart-table">
              <thead>
                <tr>
                  <th>Product</th>
                  <th>Price (₹)</th>
                  <th>Quantity</th>
                  <th>Subtotal (₹)</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {cart.items.map((item, index) => (
                  <tr key={index}>
                    <td>{item.productName}</td>
                    <td>{item.price.toFixed(2)}</td>
                    <td>
                      <div className="quantity-controls">
                        <button onClick={() => updateQuantity(index, -1)}>-</button>
                        <span>{item.quantity}</span>
                        <button onClick={() => updateQuantity(index, 1)}>+</button>
                      </div>
                    </td>
                    <td>{(item.price * item.quantity).toFixed(2)}</td>
                    <td>
                      <button
                        onClick={() => deleteItem(item.productId)}
                        className="delete-btn"
                        title="Remove item"
                      >
                        🗑️
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            <div className="total-price">Total: ₹{cart.totalPrice.toFixed(2)}</div>
            <button className="checkout-btn" onClick={handleCheckout}>Proceed to Checkout</button>
          </>
        )}
      </div>
    </>
  );
};

export default CartPage;
