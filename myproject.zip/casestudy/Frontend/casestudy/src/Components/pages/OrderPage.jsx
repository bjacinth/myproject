import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import '../cssfiles/OrderPage.css';

const OrderPage = () => {
    const { profileId } = useParams();
    const navigate = useNavigate();
    const [cart, setCart] = useState(null);
    const [error, setError] = useState(null);
    const [wallet, setWallet] = useState(null);
    const [addresses, setAddresses] = useState([]);
    const [selectedAddress, setSelectedAddress] = useState(null);
    const [paymentMethod, setPaymentMethod] = useState("Wallet"); 

    useEffect(() => {
        const fetchCart = async () => {
            try {
                const res = await fetch(`http://localhost:9193/cart/profile/${profileId}`);
                const data = await res.json();
                setCart(data);
            } catch (err) {
                setError("Failed to load cart.");
            }
        };

        const fetchWallet = async () => {
            try {
                const res = await axios.get(`http://localhost:9195/wallet/walletId/${profileId}`);
                setWallet(res.data);
            } catch (err) {
                console.error("Wallet fetch error:", err);
            }
        };

        const fetchAddresses = async () => {
            try {
                const res = await axios.get(`http://localhost:9191/profile/address/${profileId}`);
                setAddresses(res.data);
            } catch (err) {
                console.error("Address fetch error:", err);
            }
        };

        fetchCart();
        fetchWallet();
        fetchAddresses();
    }, [profileId]);

    const handlePlaceOrder = async () => {
        try {
            if (!selectedAddress) {
                alert("Please select a delivery address.");
                return;
            }

            const profileRes = await axios.get(`http://localhost:9191/profile/id/${profileId}`);
            const profile = profileRes.data;

            const order = {
                orderDate: new Date().toISOString().split("T")[0],
                profileId: profile.profileId,
                fullName: profile.fullName,
                emailId: profile.emailId,
                mobileNumber: profile.mobileNumber,
                ammountPaid: cart.totalPrice,
                modeOfPayment: paymentMethod,
                orderStatus: paymentMethod === "Razorpay" ? "Pending" : "Processing",
                quantity: cart.items.reduce((sum, item) => sum + item.quantity, 0),
                address: selectedAddress,
                items: cart.items
            };

            const orderRes = await axios.post("http://localhost:9194/orders/place", order);
            const orderId = orderRes.data.orderId;

            if (paymentMethod === "Wallet") {
                if (!wallet || cart.totalPrice > wallet.currentBal) {
                    alert("Insufficient wallet balance.");
                    return;
                }

                await axios.delete(`http://localhost:9193/cart/delete/${profile.profileId}`);
                alert("✅ Order placed using Wallet!");
                navigate("/home");

            } else if (paymentMethod === "CashOnDelivery") {
                await axios.delete(`http://localhost:9193/cart/delete/${profile.profileId}`);
                alert("✅ Order placed with Cash on Delivery!");
                navigate("/home");

            } else if (paymentMethod === "Razorpay") {
                const paymentLinkRes = await axios.get(`http://localhost:9194/orders/create-payment-link`, {
                    params: {
                        profileId: profileId,
                        amount: cart.totalPrice,
                        orderId: orderId
                    }
                });

                const paymentUrl = paymentLinkRes.data;
                if (paymentUrl.startsWith("http")) {
                    window.location.href = paymentUrl;
                    await axios.delete(`http://localhost:9193/cart/delete/${profile.profileId}`);
                } else {
                    alert("❌ Failed to generate Razorpay payment link.");
                }
            }

        } catch (error) {
            console.error("Checkout failed:", error);
            alert("❌ Checkout failed. Please try again.");
        }
    };


    if (error) return <div className="order-container">Error: {error}</div>;
    if (!cart) return <div className="order-container">Loading order details...</div>;

    return (
        <div className="order-container">
            <h1>🧾 Review Your Order</h1>

            <table className="order-table">
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Price (₹)</th>
                        <th>Quantity</th>
                        <th>Subtotal (₹)</th>
                    </tr>
                </thead>
                <tbody>
                    {cart.items.map((item, index) => (
                        <tr key={index}>
                            <td>{item.productName}</td>
                            <td>{item.price.toFixed(2)}</td>
                            <td>{item.quantity}</td>
                            <td>{(item.price * item.quantity).toFixed(2)}</td>
                        </tr>
                    ))}
                </tbody>
            </table>

            <div className="order-total">
                <strong>Total: ₹{cart.totalPrice.toFixed(2)}</strong>
            </div>

            <h2>📍 Select Delivery Address</h2>
            <table className="address-table">
                <thead>
                    <tr>
                        <th>Street</th>
                        <th>City</th>
                        <th>State</th>
                        <th>Pincode</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {addresses.map((addr, index) => (
                        <tr key={index}>
                            <td>{addr.street}</td>
                            <td>{addr.city}</td>
                            <td>{addr.state}</td>
                            <td>{addr.pincode}</td>
                            <td>
                                <button onClick={() => setSelectedAddress(addr)}>
                                    {selectedAddress?.addressId === addr.addressId ? "✅ Selected" : "Select"}
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>

            <h2>💳 Select Payment Method</h2>
            <div className="payment-options">
                <label>
                    <input
                        type="radio"
                        value="Wallet"
                        checked={paymentMethod === "Wallet"}
                        onChange={(e) => setPaymentMethod(e.target.value)}
                    />
                    Wallet (Balance: ₹{wallet?.currentBal?.toFixed(2) || "0.00"})
                </label>
                <label>
                    <input
                        type="radio"
                        value="Razorpay"
                        checked={paymentMethod === "Razorpay"}
                        onChange={(e) => setPaymentMethod(e.target.value)}
                    />
                    Razorpay
                </label>
                <label>
                    <input
                        type="radio"
                        value="CashOnDelivery"
                        checked={paymentMethod === "CashOnDelivery"}
                        onChange={(e) => setPaymentMethod(e.target.value)}
                    />
                    Cash on Delivery
                </label>
            </div>

            <button className="place-order-btn" onClick={handlePlaceOrder}>
                ✅ Proceed to Checkout
            </button>
        </div>
    );
};

export default OrderPage;
