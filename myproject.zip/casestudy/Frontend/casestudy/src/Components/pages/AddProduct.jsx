import React, { useState } from "react";
import "../cssfiles/AddProduct.css";
import DropdownMenu from "../pages/Dropdown.jsx"; 
const AddProduct = () => {
  const [product, setProduct] = useState({
    productName: "",
    productType: "",
    category: "",
    price: "",
    description: "",
    specification: {},
    image: "",
  });

  const handleChange = (e) => {
    setProduct({ ...product, [e.target.name]: e.target.value });
  };

  const handleSpecificationChange = (e) => {
    setProduct({
      ...product,
      specification: {
        ...product.specification,
        [e.target.name]: e.target.value,
      },
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

   const payload = {
  ...product,
  image: [product.image],
  specification: product.specification,
};


    fetch("http://localhost:9192/product/add", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    })
      .then((res) => res.json())
      .then((data) => {
        console.log("Product added:", data);
        alert("Product added successfully!");
      })
      .catch((err) => {
        console.error("Error:", err);
        alert("Failed to add product.");
      });
  };

  return (
    <>
    <div className="header">
                <DropdownMenu />
            </div>
    <div className="add-product">
     <h2 className="add-product-title">Add New Product</h2>
      <form className="product-form" onSubmit={handleSubmit}>
        <input
          type="text"
          name="productName"
          placeholder="Product Name"
          value={product.productName}
          onChange={handleChange}
          required
        />
        <input
          type="text"
          name="productType"
          placeholder="Product Type"
          value={product.productType}
          onChange={handleChange}
          required
        />
        <input
          type="text"
          name="category"
          placeholder="Category"
          value={product.category}
          onChange={handleChange}
          required
        />
        <input
          type="number"
          name="price"
          placeholder="Price"
          value={product.price}
          onChange={handleChange}
          required
        />
        <textarea
          name="description"
          placeholder="Description"
          value={product.description}
          onChange={handleChange}
          required
        />
        <input
          type="text"
          name="Camera"
          placeholder="Camera (if applicable)"
          onChange={handleSpecificationChange}
        />
        <input
          type="text"
          name="Battery"
          placeholder="Battery (if applicable)"
          onChange={handleSpecificationChange}
        />
        <input
          type="text"
          name="image"
          placeholder="Image URL"
          value={product.image}
          onChange={handleChange}
          required
        />
        <button type="submit">Add Product</button>
      </form>
    </div>
    </>
  );
};

export default AddProduct;
