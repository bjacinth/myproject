import React from 'react';
import '../cssfiles/AboutUsPage.css';

const AboutUs = () => {
  return (
    <div className="about-container">
      <div className="about-card">
        <h1 className="about-title">About Us</h1>
        <p className="about-tagline">Your one-stop destination for everything you love to shop!</p>

        <section className="about-section">
          <h2>Who We Are</h2>
          <p>
            Welcome to <strong>Jmart</strong> — where shopping meets simplicity. We are a passionate team of designers, developers, and dreamers who believe that online shopping should be seamless, secure, and satisfying.
          </p>
        </section>

        <section className="about-section">
          <h2>What We Do</h2>
          <p>
            From fashion to electronics, home essentials to beauty products, we bring you a curated collection of high-quality items at unbeatable prices. Our platform connects customers with trusted merchants and ensures a smooth delivery experience.
          </p>
        </section>

        <section className="about-section">
          <h2>Why Choose Us?</h2>
          <ul className="about-list">
            <li>✅ Wide range of products</li>
            <li>🚚 Fast & reliable delivery</li>
            <li>🔒 Secure payments</li>
            <li>💬 24/7 customer support</li>
            <li>🌱 Eco-friendly packaging</li>
          </ul>
        </section>

        <section className="about-section">
          <h2>Our Mission</h2>
          <p>
            To empower every shopper with convenience, confidence, and joy — one purchase at a time.
          </p>
        </section>

        <section className="about-section">
          <h2>Join Us</h2>
          <p>
            Whether you're a customer, a seller, or a delivery partner — we welcome you to be part of our growing family. Let’s build the future of shopping together.
          </p>
        </section>
      </div>
    </div>
  );
};

export default AboutUs;
