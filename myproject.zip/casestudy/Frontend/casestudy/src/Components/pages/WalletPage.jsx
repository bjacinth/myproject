import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import styles from "../cssfiles/WalletPage.module.css";
import Dropdown from '../pages/Dropdown.jsx';

const WalletPage = () => {
    const { walletId } = useParams();
    const [wallet, setWallet] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [amount, setAmount] = useState("");
    const [showModal, setShowModal] = useState(false);
    const profileId = localStorage.getItem("profileId");


    useEffect(() => {
        const fetchWallet = async () => {
            try {
                const response = await axios.get(`http://localhost:9195/wallet/walletId/${walletId}`);
                setWallet(response.data);
            } catch (err) {
                console.error("Error fetching wallet:", err);
                setWallet(null); 
            } finally {
                setLoading(false);
            }
        };

        fetchWallet();
    }, [walletId]);

    const handleAddMoney = async () => {
        try {
            const response = await axios.post(
                "http://localhost:9195/wallet/create-payment-link",
                null,
                {
                    params: {
                        profileId: wallet.profileId,
                        amount: amount
                    }
                }
            );
            const paymentLink = typeof response.data === "string" ? response.data : response.data.paymentLink;
            if (paymentLink) {
                window.location.href = paymentLink;
            } else {
                alert("Invalid payment link received.");
            }
        } catch (err) {
            console.error("Error creating payment link:", err);
            alert("Failed to create payment link.");
        }
    };

    const handleCreateWallet = async () => {
    try {
        const response = await axios.post(`http://localhost:9195/wallet/createwallet/${profileId}`);
        setWallet(response.data);
        alert("Wallet created successfully!");
    } catch (err) {
        console.error("Error creating wallet:", err);
        alert("Failed to create wallet.");
    }
};


    if (loading) return <div className={styles.loading}>Loading wallet...</div>;
    if (error) return <div className={styles.error}>{error}</div>;

    if (!wallet) {
        return (
            <div className={styles.pageContainer}>
                <div className="header">
                    <Dropdown />
                </div>
                <h1 className={styles.pageTitle}>No Wallet Found</h1>
                <p>You don't have a wallet yet. Click below to create one and add money.</p>
                <button className={styles.addMoneyButton} onClick={handleCreateWallet}>
                    Create Wallet
                </button>
            </div>
        );
    }

    return (
        <>
        <div className="header">
                <Dropdown />
            </div>
            <div className={styles.pageContainer}>
            
            <h1 className={styles.pageTitle}>Wallet Overview</h1>

            <div className={styles.summaryContainer}>
                <div className={styles.summaryCard}>
                    <h3>Wallet ID</h3>
                    <p>{wallet.walletId}</p>
                </div>
                <div className={styles.summaryCard}>
                    <h3>Current Balance</h3>
                    <p>₹{wallet.currentBal.toLocaleString()}</p>
                </div>
                <div className={styles.summaryCard}>
                    <h3>Profile ID</h3>
                    <p>{wallet.profileId}</p>
                </div>
            </div>

            <button className={styles.addMoneyButton} onClick={() => setShowModal(true)}>Add Money</button>

            {showModal && (
                <div className={styles.modalOverlay}>
                    <div className={styles.modalContent}>
                        <h2>Add Money</h2>
                        <label>Amount:</label>
                        <input
                            type="number"
                            value={amount}
                            onChange={(e) => setAmount(e.target.value)}
                            className={styles.inputField}
                        />
                        <div className={styles.modalActions}>
                            <button onClick={handleAddMoney} className={styles.submitButton}>Submit</button>
                            <button onClick={() => setShowModal(false)} className={styles.cancelButton}>Cancel</button>
                        </div>
                    </div>
                </div>
            )}

            <div className={styles.tableContainer}>
                <h2>Transaction History</h2>
                <table className={styles.transactionTable}>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Type</th>
                            <th>Amount</th>
                            <th>Date & Time</th>
                            <th>Remarks</th>
                        </tr>
                    </thead>
                    <tbody>
                        {wallet.statements.map((stmt) => (
                            <tr key={stmt.statementId}>
                                <td>{stmt.statementId}</td>
                                <td>{stmt.transactionType}</td>
                                <td>₹{stmt.amount}</td>
                                <td>{new Date(stmt.dateTime).toLocaleString()}</td>
                                <td>{stmt.transactionRemarks || "—"}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
        </>
        
    );
};

export default WalletPage;
