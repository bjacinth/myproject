import React, { useEffect, useState } from "react";
import '../cssfiles/HomePage.css';
import { useNavigate } from "react-router-dom";
import DropdownMenu from "../pages/Dropdown.jsx";

const HomePage = () => {
  const [products, setProducts] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [sortOrder, setSortOrder] = useState("default");
  const [showPopup, setShowPopup] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const popupShown = localStorage.getItem("homePopupShown");
    if (!popupShown) {
      setShowPopup(true);
      localStorage.setItem("homePopupShown", "true");
      setTimeout(() => setShowPopup(false), 2000);
    }

    fetch("http://localhost:9192/product/all")
      .then((response) => response.json())
      .then((data) => {
        setProducts(data);
        setFilteredProducts(data);
      })
      .catch((error) => console.error("Error fetching products:", error));
  }, []);

  const handleSearchAndFilter = () => {
    let filtered = products.filter(product =>
      product.productName.toLowerCase().includes(searchTerm.toLowerCase()) &&
      (selectedCategory === "All" || product.category === selectedCategory)
    );

    if (sortOrder === "lowToHigh") {
      filtered.sort((a, b) => a.price - b.price);
    } else if (sortOrder === "highToLow") {
      filtered.sort((a, b) => b.price - a.price);
    }

    setFilteredProducts(filtered);
  };

  useEffect(() => {
    handleSearchAndFilter();
  }, [searchTerm, selectedCategory, sortOrder]);

  const uniqueCategories = ["All", ...new Set(products.map(p => p.category))];

  return (
    <div className="homepage">
      <div className="header">
        <DropdownMenu />

        <input
          className="headerinput"
          type="text"
          placeholder="Search products..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />

        
      </div>

      <div className="filters">
        <div className="filter-group">
          <label>Category:</label>
          <select value={selectedCategory} onChange={(e) => setSelectedCategory(e.target.value)}>
            {uniqueCategories.map((cat, index) => (
              <option key={index} value={cat}>{cat}</option>
            ))}
          </select>
        </div>

        <div className="filter-group">
          <label>Sort by:</label>
          <select value={sortOrder} onChange={(e) => setSortOrder(e.target.value)}>
            <option value="default">Default</option>
            <option value="lowToHigh">Price: Low to High</option>
            <option value="highToLow">Price: High to Low</option>
          </select>
        </div>

        <button
          className="clear-button"
          onClick={() => {
            setSearchTerm("");
            setSelectedCategory("All");
            setSortOrder("default");
            setFilteredProducts(products);
          }}
        >
          Clear Filters
        </button>
      </div>

      {filteredProducts.length === 0 && (
        <div className="no-products">
          😕 No products found. Try adjusting your search or filters.
        </div>
      )}



      {showPopup && (
        <div className="success-popup">
          🎉 Welcome to your homepage!
        </div>
      )}

      <div className="products">
        {filteredProducts.map((product) => (
          <div
            key={product.productId}
            className="product-card"
            onClick={() => navigate(`/product/${product.productId}`)}
          >
            <img src={product.image[0]} alt={product.productName} />
            <h3>{product.productName}</h3>
            <p>{product.description}</p>
            <span>₹{product.price}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default HomePage;
