import React from "react";
import "../cssfiles/Header.css";
import { useNavigate } from "react-router-dom";

const Header = () => {
  const navigate = useNavigate();
  return (
    <header className="header1" onClick={()=>navigate("/home")}>
      <div className="logo">Jmart</div>
      
        
      
    </header>
  );
};

export default Header;