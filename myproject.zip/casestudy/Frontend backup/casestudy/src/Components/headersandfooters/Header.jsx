import React from "react";
import "../cssfiles/Header.css";
import { useNavigate } from "react-router-dom";

const Header = () => {
  const navigate = useNavigate();
  return (
    <header className="heeader" onClick={()=>navigate("/home")}>
      <div className="logo">Jmart</div>
      <nav>
        
      </nav>
    </header>
  );
};

export default Header;