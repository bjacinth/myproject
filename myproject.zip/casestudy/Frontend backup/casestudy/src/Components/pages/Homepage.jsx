import React, { useEffect, useState } from "react";
import '../cssfiles/HomePage.css';
import { useNavigate } from "react-router-dom";
import DropdownMenu from "../pages/Dropdown.jsx";

const HomePage = () => {
  const [products, setProducts] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [showPopup, setShowPopup] = useState(false);
  const navigate = useNavigate();
  const profileId = localStorage.getItem("profileId");

  useEffect(() => {
    const popupShown = localStorage.getItem("homePopupShown");
    if (!popupShown) {
      setShowPopup(true);
      localStorage.setItem("homePopupShown", "true");
      setTimeout(() => setShowPopup(false), 2000); 
    }

    fetch("http://localhost:9192/product/all")
      .then((response) => response.json())
      .then((data) => {
        setProducts(data);
        setFilteredProducts(data);
      })
      .catch((error) => console.error("Error fetching products:", error));
  }, []);

  const handleSearch = () => {
    const filtered = products.filter(product =>
      product.productName.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setFilteredProducts(filtered);
  };

  return (
    <div className="homepage">
      <div className="header">
        <DropdownMenu />
        <input
          className="headerinput"
          type="text"
          placeholder="Search..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        <button className="searchbutton" onClick={handleSearch}>Search</button>
      </div>

      {showPopup && (
        <div className="success-popup">
          🎉 Welcome to your homepage!
        </div>
      )}

      <div className="products">
        {filteredProducts.map((product) => (
          <div key={product.productId} className="product-card" onClick={() => navigate(`/product/${product.productId}`)}>
            <img src={product.image[0]} alt={product.productName} />
            <h3>{product.productName}</h3>
            <p>{product.description}</p>
            <span>₹{product.price}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default HomePage;
