import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import "../cssfiles/Dropdown.css";

const DropdownMenu = () => {
    const [isOpen, setIsOpen] = useState(false);
    const navigate = useNavigate();
    const dropdownRef = useRef(null);

    const toggleDropdown = () => {
        setIsOpen(!isOpen);
    };

    const handleClickOutside = (event) => {
        if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
            setIsOpen(false);
        }
    };

    useEffect(() => {
        document.addEventListener("mousedown", handleClickOutside);
        return () => {
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, []);

    const handleProfileClick = () => {
        const profileId = localStorage.getItem("profileId");
        if (profileId) {
            navigate(`/profile/id/${profileId}`);
        } else {
            alert("Please log in to view your profile.");
            navigate("/login");
        }
    };

    const handleWalletClick = () => {
        const profileId = localStorage.getItem("profileId");
        if (profileId) {
            navigate(`/wallet/walletId/${profileId}`);
        } else {
            alert("Please log in to view your wallet.");
            navigate("/login");
        }
    };

    const handleOrdersClick = () => {
        const profileId = localStorage.getItem("profileId");
        if(profileId) {
            navigate(`/orders/customer/${profileId}`);
        } else {
            alert("Please log in to view your orders.");
            navigate("/login");
        }
    }

    const handleCartClick = () => {
        const profileId = localStorage.getItem("profileId");
        if(profileId) {
            navigate(`/cart/profileId/${profileId}`);
        } else {
            alert("Please log in to view your cart.");
            navigate("/login");
        }
    }

    const handleLogout = () => {
        localStorage.removeItem("profileId");
        navigate("/login");
    };

    return (
        <div className="dropdown" ref={dropdownRef}>
            <button className="dropbtn" onClick={toggleDropdown}>
                Menu ▼
            </button>
            {isOpen && (
                <div className="dropdown-content">
                    <button onClick={() => navigate("/home")}>Home</button>
                    <button onClick={handleWalletClick}>Wallet</button>
                    <button onClick={handleCartClick}>Cart</button>
                    <button onClick={handleProfileClick}>Profile</button>
                    <button onClick={handleOrdersClick}>Orders</button>
                    <button onClick={handleLogout}>Logout</button>
                </div>
            )}
        </div>
    );
};

export default DropdownMenu;
