import React, { useState } from 'react';
import "../cssfiles/AdminPage.css";

const AdminUserPage = () => {
  const [users, setUsers] = useState([]);
  const [error, setError] = useState('');

  const fetchUsers = async () => {
    try {
      const response = await fetch('http://localhost:9191/profile/all');
      if (!response.ok) throw new Error('Failed to fetch users');
      const data = await response.json();
      setUsers(data);
      setError('');
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="admin-container">
      <h1>Admin - Manage Users</h1>
      <button onClick={fetchUsers}>Load Users</button>
      {error && <p className="error">{error}</p>}
      <div className="user-cards">
        {users.map((user) => (
          <div key={user.profileId} className="user-card">
            <img src={user.image} alt={user.fullName} className="user-image" />
            <div className="user-info">
              <h2>{user.fullName}</h2>
              <p><strong>Email:</strong> {user.emailId}</p>
              <p><strong>Mobile:</strong> {user.mobileNumber}</p>
              <p><strong>Role:</strong> {user.role}</p>
              <p><strong>About:</strong> {user.about}</p>
              <p><strong>DOB:</strong> {user.dateOfBirth}</p>
              <p><strong>Gender:</strong> {user.gender}</p>
              <div className="address-section">
                <strong>Addresses:</strong>
                <ul>
                  {user.address.map((addr) => (
                    <li key={addr.addressId}>
                      {addr.houseNumber}, {addr.streetName}, {addr.colonyName}, {addr.city}, {addr.state} - {addr.pincode}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AdminUserPage;
