import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import '../cssfiles/Merchant.css';
import DropdownMenu from '../pages/Dropdown.jsx';

const MerchantDashboard = () => {
    const navigate = useNavigate();
    const [products, setProducts] = useState([]);
    const [showEditModal, setShowEditModal] = useState(false);
    const [selectedProduct, setSelectedProduct] = useState(null);

    useEffect(() => {
        fetch('http://localhost:9192/product/all')
            .then((res) => res.json())
            .then((data) => setProducts(data))
            .catch((err) => console.error('Error fetching products:', err));
    }, []);

    const handleEdit = (product) => {
        setSelectedProduct({ ...product }); 
        setShowEditModal(true);
    };

    const handleModalChange = (e) => {
        const { name, value } = e.target;
        setSelectedProduct({ ...selectedProduct, [name]: value });
    };

    const handleSpecChange = (e) => {
        const { name, value } = e.target;
        setSelectedProduct({
            ...selectedProduct,
            specification: {
                ...selectedProduct.specification,
                [name]: value,
            },
        });
    };

    const handleImageChange = (e) => {
        const { name, value } = e.target;
        const index = parseInt(name.replace("image", ""));
        const updatedImages = [...selectedProduct.image];
        updatedImages[index] = value;
        setSelectedProduct({ ...selectedProduct, image: updatedImages });
    };

    const handleUpdateProduct = async (e) => {
        e.preventDefault();
        try {
            const response = await fetch('http://localhost:9192/product/update', {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(selectedProduct),
            });

            if (response.ok) {
                alert('Product updated successfully');
                setShowEditModal(false);
               
                const updated = await fetch('http://localhost:9192/product/all').then(res => res.json());
                setProducts(updated);
            } else {
                alert('Failed to update product');
            }
        } catch (error) {
            console.error('Update error:', error);
            alert('Error updating product');
        }
    };
    const handleDelete = async (productId) => {
    const confirmDelete = window.confirm("Are you sure you want to delete this product?");
    if (!confirmDelete) return;

    try {
        const response = await fetch(`http://localhost:9192/product/${productId}`, {
            method: 'DELETE',
        });

        if (response.ok) {
            alert("Product deleted successfully.");
            
        } else {
            alert("Failed to delete the product.");
        }
    } catch (error) {
        console.error("Error deleting product:", error);
        alert("An error occurred while deleting the product.");
    }
};

    return (
        <>
            <div className="header">
                <DropdownMenu />
            </div>
            <div className="merchant-dashboard">
                <h2 color='white'>Merchant Dashboard</h2>
                <button className='add-product-button' onClick={() => navigate('/merchant/add')}>Add New Product</button>
                <div className="dashboard-options">
                    {products.map((product) => (
                        <div key={product.productId} className="product-card">
                            <img src={product.image[0]} alt={product.productName} className="M-product-image" />
                            <h3>{product.productName}</h3>
                            <p className="product-type">{product.productType} - {product.category}</p>
                            <p className="product-description">{product.description}</p>
                            <p className="product-price"><h3>Price</h3>₹{product.price}</p>
                            <br/>
                            <span>
                                 <table>
                            <div className="product-specs">
                                {Object.entries(product.specification).map(([key, value]) => (
                                    <p key={key}><strong>{key}:</strong> {value}</p>
                                ))}
                            </div>
                            </table>

                            </span>
                           

                            <div className="product-reviews">
                                <h4>Reviews:</h4>
                                {Object.entries(product.review).map(([id, text]) => (
                                    <p key={id}>⭐ {product.rating[id]} - {text}</p>
                                ))}
                            </div>

                            <div className="product-actions">
                                <button onClick={() => handleEdit(product)}>Edit</button>
                                <button onClick={() => handleDelete(product.productId)}>Delete</button>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            {showEditModal && selectedProduct && (
                <div className="modal-overlay">
                    <div className="modal-content">
                        <h3>Edit Product</h3>
                        <form onSubmit={handleUpdateProduct}>
                            <label>Product Name</label>
                            <input type="text" name="productName" value={selectedProduct.productName} onChange={handleModalChange} required />

                            <label>Product Type</label>
                            <input type="text" name="productType" value={selectedProduct.productType} onChange={handleModalChange} required />

                            <label>Category</label>
                            <input type="text" name="category" value={selectedProduct.category} onChange={handleModalChange} required />

                            <label>Price (₹)</label>
                            <input type="number" name="price" value={selectedProduct.price} onChange={handleModalChange} required />

                            <label>Description</label>
                            <textarea name="description" value={selectedProduct.description} onChange={handleModalChange} required />

                            <label>Image URL 1</label>
                            <input type="text" name="image0" value={selectedProduct.image[0]} onChange={handleImageChange} />

                            <label>Image URL 2</label>
                            <input type="text" name="image1" value={selectedProduct.image[1]} onChange={handleImageChange} />

                            <label>Camera</label>
                            <input type="text" name="Camera" value={selectedProduct.specification.Camera} onChange={handleSpecChange} />

                            <label>Battery</label>
                            <input type="text" name="Battery" value={selectedProduct.specification.Battery} onChange={handleSpecChange} />

                            <label>Display</label>
                            <input type="text" name="Display" value={selectedProduct.specification.Display} onChange={handleSpecChange} />

                            <div className="modal-actions">
                                <button type="submit">Update</button>
                                <button type="button" onClick={() => setShowEditModal(false)}>Cancel</button>
                            </div>
                        </form>

                    </div>
                </div>
            )}
        </>
    );
};

export default MerchantDashboard;
